import numpy as np  # Libreria per calcoli numerici e array

# Numero di vettori (campioni di input) e dimensione di ogni vettore
num_vettori = 5     # Simuliamo 5 campioni di dati in input
dim_vettore = 3     # Ogni campione ha 3 caratteristiche (es. temperatura, pressione, umidità)

# Creiamo una lista di vettori casuali, ognuno lungo dim_vettore
# np.random.rand(dim) genera numeri float casuali tra 0 e 1
# La list comprehension crea una lista di array (ogni array è un campione)
vettori = [np.random.rand(dim_vettore) for _ in range(num_vettori)]

# Stampiamo gli input generati
print("Vettori casuali:")
for v in vettori:
    print(v)

# Numero di neuroni nel layer di destinazione
neuroni = 4  # Ad esempio, 4 neuroni nascosti o di output

# Creiamo la matrice dei pesi per il layer:
# dimensione = (num_input_per_campione, num_neuroni)
# Ogni colonna rappresenta i pesi di un neurone verso tutti gli input
pesi = np.random.rand(dim_vettore, neuroni)

print("\nMatrice dei pesi:")
print(pesi)

# Calcolo dell'uscita del layer per ogni vettore di input:
# np.dot(v, pesi) = prodotto scalare tra il vettore di input e la matrice dei pesi
# Risultato: un array con 'neuroni' valori, uno per ogni neurone
uscite = [np.dot(v, pesi) for v in vettori]

# Stampa delle uscite calcolate
print("\nUscite del layer:")
for u in uscite:
    print(u)
