import random

# Matrice pesi input → hidden (2 input, 2 neuroni nascosti)
w_ih = [
    [random.random(), random.random()],  # pesi verso neurone nascosto 1
    [random.random(), random.random()]   # pesi verso neurone nascosto 2
]

print("Matrice pesi input → hidden:")
print(w_ih)
