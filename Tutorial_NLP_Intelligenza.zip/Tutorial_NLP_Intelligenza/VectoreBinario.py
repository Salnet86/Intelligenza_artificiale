# Frase di input
frase = "ciao come stai"
parole_frase = frase.split()

# Vocabolario costruito prima
vocabolario = ["ciao", "come", "stai", "va"]

# Vettore binario inizializzato a 0
vettore_binario = [0] * len(vocabolario)

# Riempimento vettore binario
for i, parola in enumerate(vocabolario):
    if parola in parole_frase:
        vettore_binario[i] = 1

print("Frase:", frase)
print("Vettore binario:", vettore_binario)
