import random
import math

# Numero di intenti e numero di parole nel vocabolario
num_intenti = 4 # accendi, spegni, imposta temperatura, chiedi meteo
num_parole = 11 # accendi, spegni, imposta, temperatura, luce, riscaldamento, cucina, 22, gradi, tempo, oggi

# Inizializzazione dei pesi casuali (valori tra -1 e 1)
pesi = []
for _ in range(num_intenti):
pesi.append([random.uniform(-1, 1) for _ in range(num_parole)])

# Mostra i pesi casuali
print("Pesi casuali:")
for i in range(num_intenti):
print(pesi[i])

# Vettore Bag of Words per la frase "Imposta la temperatura a 22 gradi"
x = [0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0] # Conteggio delle parole nella frase

# Calcolo dei punteggi z = W * x (prodotto matrice-vettore)
z = []
for i in range(num_intenti):
score = 0
for j in range(num_parole):
score += pesi[i][j] * x[j] # Prodotto scalare tra pesi e parole
z.append(score)

# Funzione softmax
def softmax(z):
max_z = max(z)
exp_z = [math.exp(score - max_z) for score in z] # Stabilità numerica
sum_exp_z = sum(exp_z)
return [score / sum_exp_z for score in exp_z]

# Calcolare le probabilità usando softmax
prob = softmax(z)

# Intenti possibili
intent_names = ["accendi", "spegni", "imposta temperatura", "chiedi meteo"]

# Visualizzare i punteggi e le probabilità
print("\nPunteggi z per ogni intento:", z)
print("Probabilità softmax:", prob)
print("\nIntento predetto:", intent_names[prob.index(max(prob))])

# Estrazione delle entità
entities = {}
if "22" in ["22"]:
entities["valore"] = 22
if "gradi" in ["gradi"]:
entities["unità"] = "gradi"

print("Entità estratte:", entities)
