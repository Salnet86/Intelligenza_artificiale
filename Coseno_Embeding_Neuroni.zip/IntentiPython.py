import math
import numpy as np

# Vocabolario (ordine delle parole)
vocab = ["accendi", "spegni", "imposta", "temperatura", "luce", "riscaldamento", "cucina", "22", "gradi", "tempo", "oggi"]

# Vettore bag of words della frase "Imposta la temperatura a 22 gradi"
# 1 se la parola è presente, 0 altrimenti
x = np.array([0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0])

# Pesi per ogni intento (ogni riga è un intento, ogni colonna una parola)
# ordiniamo gli intenti così: accendi=0, spegni=1, imposta temperatura=2, chiedi meteo=3
weights = np.array([
[3, 0, 0, 0, 3, 0, 1, 0, 0, 0, 0], # accendi
[0, 3, 0, 0, 0, 3, 1, 0, 0, 0, 0], # spegni
[0, 0, 4, 3, 0, 0, 0, 2, 1, 0, 0], # imposta temperatura
[0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2], # chiedi meteo
])

# Calcolo punteggi z = W * x (prodotto matrice-vettore)
z = weights.dot(x)

# Funzione softmax
def softmax(z):
exp_z = np.exp(z - np.max(z)) # per stabilità numerica
return exp_z / exp_z.sum()

prob = softmax(z)

# Mapping codice intento -> nome
intent_names = ["accendi", "spegni", "imposta temperatura", "chiedi meteo"]

print("Punteggi z per ogni intento:", z)
print("Probabilità softmax:", prob)
print("\nIntento predetto:", intent_names[np.argmax(prob)])

# Estrazione entità semplice (per esempio, cercando numeri e unità)
entities = {}
if "22" in [vocab[i] for i, val in enumerate(x) if val == 1]:
entities["valore"] = 22
if "gradi" in [vocab[i] for i, val in enumerate(x) if val == 1]:
entities["unità"] = "gradi"

print("Entità estratte:", entities)
