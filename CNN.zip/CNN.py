from tensorflow.keras.preprocessing import image
import numpy as np

# Carica e preprocessa una nuova immagine
img = image.load_img('nuova_immagine.jpg', target_size=(224, 224))
img_array = image.img_to_array(img)
img_array = np.expand_dims(img_array, axis=0)  # Aggiungi una dimensione batch
img_array /= 255.0  # Normalizza i valori dei pixel

# Previsione
predizione = model.predict(img_array)
if predizione > 0.5:
    print("La persona è una donna.")
else:
    print("La persona è un uomo.")
