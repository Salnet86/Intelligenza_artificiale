from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense

# Creare il modello CNN
model = Sequential()

# Aggiungere strati convoluzionali e di pooling
model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Flatten())

# Strato completamente connesso per la classificazione finale
model.add(Dense(128, activation='relu'))
model.add(Dense(1, activation='sigmoid'))  # Output binario: uomo (0) o donna (1)

# Compilare il modello
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
# Addestramento del modello
model.fit(train_generator, epochs=10)
