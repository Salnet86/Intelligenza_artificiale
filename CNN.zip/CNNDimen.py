from tensorflow.keras.preprocessing.image import ImageDataGenerator

# Creare un generatore per caricare e preprocessare le immagini
datagen = ImageDataGenerator(rescale=1./255)

# Caricare il dataset (esempio con immagini in cartelle 'donna' e 'uomo')
train_generator = datagen.flow_from_directory(
    'dataset/',  # Directory contenente le immagini
    target_size=(224, 224),  # Ridimensiona a 224x224 px
    batch_size=32,
    class_mode='binary'  # Classificazione binaria: uomo o donna
)
