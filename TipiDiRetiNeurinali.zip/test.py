from PIL import Image
import math

def carica_e_grigio(percorso, size=(50, 50)):
    img = Image.open(percorso).convert('L')  # Converti in scala di grigi
    img = img.resize(size)
    pixels = list(img.getdata())  # Ottieni i pixel in formato lista
    return pixels

def distanza_euclidea(v1, v2):
    if len(v1) != len(v2):
        raise ValueError("Le immagini devono avere la stessa dimensione")
    somma = 0
    for i in range(len(v1)):
        diff = v1[i] - v2[i]
        somma += diff * diff
    return math.sqrt(somma)

# Carica le immagini
vettore1 = carica_e_grigio("martina.jpg")
vettore2 = carica_e_grigio("martina.jpg")

# Calcola la distanza
distanza = distanza_euclidea(vettore1, vettore2)

# Risultato
print(f"Distanza: {distanza:.2f}")
if distanza < 1000:
    print("Probabilmente è la stessa persona.")
else:
    print("Probabilmente sono persone diverse.")
