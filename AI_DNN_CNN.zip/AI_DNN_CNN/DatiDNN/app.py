import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt

# =========================================================
# 1. Leggi dati JSON
# =========================================================
with open("dati.json", "r") as f:
    dati_json = json.load(f)

# Convertiamo in DataFrame
data = pd.DataFrame(dati_json)

# Separiamo input e target
X = data[['ora', 'umidita', 'pressione']]
y = data['temperatura']

# Normalizzazione
scaler_X = MinMaxScaler()
X_scaled = scaler_X.fit_transform(X)

# Normalizziamo anche y per applicare la sigmoide
scaler_y = MinMaxScaler()
y_scaled = scaler_y.fit_transform(y.values.reshape(-1,1))

# =========================================================
# 2. Creiamo rete neurale DNN
# =========================================================
model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(3,)),
    layers.Dense(64, activation='relu'),
    layers.Dense(1, activation='sigmoid')  # Sigmoide per output normalizzato tra 0 e 1
])

model.compile(optimizer='adam', loss='mse', metrics=['mae'])
model.fit(X_scaled, y_scaled, epochs=200, verbose=0)

# =========================================================
# 3. Predizioni sul dataset
# =========================================================
y_pred_scaled = model.predict(X_scaled)
y_pred = scaler_y.inverse_transform(y_pred_scaled)  # Torniamo alle unità originali

# =========================================================
# 4. Visualizzazione grafico
# =========================================================
plt.figure(figsize=(8,5))
plt.plot(data['ora'], data['temperatura'], label='Temperatura reale', marker='o')
plt.plot(data['ora'], y_pred, label='Predizione DNN', marker='x')
plt.xlabel("Ora")
plt.ylabel("Temperatura °C")
plt.title("Predizione Temperatura con DNN e sigmoide")
plt.legend()
plt.grid(True)
plt.show()
