# Import delle librerie principali
from flask import Flask, render_template  # Flask per il web server e i template HTML
import tensorflow as tf                 # TensorFlow per creare e addestrare la CNN
from tensorflow.keras.preprocessing.image import ImageDataGenerator  # Per caricare e aumentare immagini
from tensorflow.keras import layers, models  # Per costruire la rete CNN
import matplotlib.pyplot as plt         # Per creare grafici
import numpy as np                      # Per gestire array numerici
import io                               # Per manipolare immagini in memoria
import base64                           # Per convertire immagini in stringhe base64 da mostrare in HTML
import os                               # Per navigare tra cartelle e file

# =========================================================
# 1. Creazione dell'app Flask
# =========================================================
app = Flask(__name__)  # Inizializza l'app Flask

# =========================================================
# 2. Parametri immagini e batch
# =========================================================
img_height, img_width = 64, 64  # Dimensioni delle immagini che la CNN aspetta
batch_size = 4                  # Numero di immagini processate per volta durante l'addestramento

# =========================================================
# 3. Data augmentation (aumentare i dati)
# =========================================================
train_datagen = ImageDataGenerator(
    rescale=1./255,              # Normalizza i pixel tra 0 e 1
    rotation_range=30,           # Ruota le immagini casualmente fino a ±30°
    width_shift_range=0.2,       # Trasla orizzontalmente fino al 20%
    height_shift_range=0.2,      # Trasla verticalmente fino al 20%
    horizontal_flip=True,        # Ribalta le immagini orizzontalmente
    validation_split=0.2         # 20% delle immagini va nel validation set
)

# =========================================================
# 4. Creazione generator per addestramento
# =========================================================
train_generator = train_datagen.flow_from_directory(
    'dataset',                   # Cartella principale con sottocartelle per ogni classe
    target_size=(img_height, img_width),  # Resize immagini
    batch_size=batch_size,       # Batch di addestramento
    class_mode='categorical',    # Output come vettore one-hot (per più classi)
    subset='training'            # Questo è il set di addestramento
)

# =========================================================
# 5. Creazione generator per validazione
# =========================================================
validation_generator = train_datagen.flow_from_directory(
    'dataset',
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='categorical',
    subset='validation'          # Questo è il set di validazione
)

# =========================================================
# 6. Costruzione CNN
# =========================================================
num_classes = len(train_generator.class_indices)  # Numero di classi (gatto, cane, ecc.)

model = models.Sequential([
    layers.Conv2D(32, (3,3), activation='relu', input_shape=(img_height,img_width,3)),  # Layer convoluzionale
    layers.MaxPooling2D(2,2),      # Pooling riduce dimensioni
    layers.Conv2D(64, (3,3), activation='relu'),  # Altro layer convoluzionale
    layers.MaxPooling2D(2,2),
    layers.Flatten(),              # Trasforma l'output 2D in vettore 1D
    layers.Dense(64, activation='relu'),  # Fully connected layer
    layers.Dense(num_classes, activation='softmax')  # Output finale con probabilità per ogni classe
])

# =========================================================
# 7. Compilazione modello
# =========================================================
model.compile(
    optimizer='adam',               # Ottimizzatore Adam
    loss='categorical_crossentropy', # Funzione di perdita per classificazione multi-classe
    metrics=['accuracy']            # Metriche da monitorare
)

# =========================================================
# 8. Addestramento CNN
# =========================================================
# Con poche immagini, poche epoche bastano per test
model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=10,       # Numero di passaggi completi sui dati
    verbose=1        # Mostra info durante l'addestramento
)

# =========================================================
# 9. Rotta principale Flask
# =========================================================
@app.route("/")
def index():
    results = []  # Lista dove salviamo predizioni

    # Ciclo sulle classi (cartelle) per predire immagini
    for classe in ['cat','dog']:
        for img_name in os.listdir(f'dataset/{classe}'):  # Legge ogni file nella cartella
            img_path = os.path.join('dataset',classe,img_name)  # Percorso completo
            img = tf.keras.preprocessing.image.load_img(img_path, target_size=(img_height,img_width))  # Carica e ridimensiona
            img_array = tf.keras.preprocessing.image.img_to_array(img)  # Trasforma in array numpy
            img_array = np.expand_dims(img_array, axis=0)/255.0  # Aggiunge dimensione batch e normalizza

            pred = model.predict(img_array)  # Predizione della rete
            class_idx = np.argmax(pred)      # Classe con probabilità massima
            class_name = list(train_generator.class_indices.keys())[class_idx]  # Nome della classe
            confidence = np.max(pred)        # Probabilità della classe predetta
            results.append((img_name, class_name, confidence))  # Salva tutto nella lista

    # =========================================================
    # 10. Creazione grafico probabilità medie
    # =========================================================
    plt.figure(figsize=(6,4))
    classes = list(train_generator.class_indices.keys())
    # Calcola media probabilità per classe
    probs_cat = [r[2] for r in results if r[1]=='cat']
    probs_dog = [r[2] for r in results if r[1]=='dog']
    plt.bar(['cat','dog'], [np.mean(probs_cat), np.mean(probs_dog)], color=['orange','blue'])
    plt.ylabel("Probabilità media")
    plt.title("Probabilità predetta dalla CNN")

    # Converti il grafico in immagine base64 da mostrare in HTML
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    grafico = base64.b64encode(buf.getvalue()).decode('utf-8')
    plt.close()

    # Renderizza template HTML e passa i risultati e grafico
    return render_template("index.html", results=results, grafico=grafico)

# =========================================================
# 11. Avvio Flask
# =========================================================
if __name__ == "__main__":
    app.run(debug=True)  # Avvia server Flask in modalità debug
