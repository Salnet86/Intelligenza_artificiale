from flask import Flask, render_template, request
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

# =========================================================
# 1. Dati finti e modello DNN
# =========================================================
np.random.seed(0)
ore = np.random.randint(0, 24, 500)
umidita = np.random.randint(20, 100, 500)
pressione = np.random.randint(980, 1050, 500)
temperatura = 10 + 0.5*ore - 0.2*(umidita/10) + 0.1*(pressione-1000) + np.random.randn(500)

data = pd.DataFrame({'ora': ore, 'umidita': umidita, 'pressione': pressione, 'temperatura': temperatura})

X = data[['ora', 'umidita', 'pressione']]
y = data['temperatura']

scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(3,)),
    layers.Dense(64, activation='relu'),
    layers.Dense(1)
])
model.compile(optimizer='adam', loss='mse', metrics=['mae'])
model.fit(X_scaled, y, epochs=100, verbose=0)

# =========================================================
# 2. Rotta principale con grafico
# =========================================================
@app.route("/", methods=["GET", "POST"])
def index():
    temperatura_prevista = None
    grafico = None
    
    if request.method == "POST":
        ora = float(request.form['ora'])
        umidita = float(request.form['umidita'])
        pressione = float(request.form['pressione'])
        
        nuovo_dato = np.array([[ora, umidita, pressione]])
        nuovo_dato_scaled = scaler.transform(nuovo_dato)
        temperatura_prevista = model.predict(nuovo_dato_scaled)[0][0]
        
        # --- Creiamo un grafico ---
        plt.figure(figsize=(6,4))
        plt.scatter(range(len(data)), data['temperatura'], label='Temperature dati finti')
        plt.scatter(len(data), temperatura_prevista, color='red', label='Predizione', s=100)
        plt.xlabel("Campioni")
        plt.ylabel("Temperatura °C")
        plt.title("Predizione temperatura DNN")
        plt.legend()
        
        # Salviamo il grafico in PNG in memoria
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        grafico = base64.b64encode(buf.getvalue()).decode('utf-8')
        plt.close()

    return render_template("index.html", temperatura=temperatura_prevista, grafico=grafico)

# =========================================================
# 3. Avvio Flask
# =========================================================
if __name__ == "__main__":
    app.run(debug=True)
