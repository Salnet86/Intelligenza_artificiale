import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import numpy as np

# =========================================================
# 1. Caricamento dataset CIFAR-10
# =========================================================
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()

# Normalizzazione dei pixel (0-1)
x_train = x_train.astype('float32') / 255
x_test = x_test.astype('float32') / 255

# =========================================================
# 2. Costruzione CNN
# =========================================================
model = models.Sequential([
    layers.Conv2D(32, (3,3), activation='relu', input_shape=(32,32,3)),
    layers.MaxPooling2D((2,2)),
    layers.Conv2D(64, (3,3), activation='relu'),
    layers.MaxPooling2D((2,2)),
    layers.Conv2D(64, (3,3), activation='relu'),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')  # 10 classi
])

# =========================================================
# 3. Compilazione modello
# =========================================================
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# =========================================================
# 4. Addestramento modello
# =========================================================
history = model.fit(x_train, y_train, epochs=10, validation_data=(x_test, y_test))

# =========================================================
# 5. Valutazione su test set
# =========================================================
test_loss, test_acc = model.evaluate(x_test, y_test)
print(f"\nAccuracy sul test set: {test_acc:.2f}")

# =========================================================
# 6. Visualizzazione di alcune predizioni
# =========================================================
class_names = ['Aereo','Automobile','Uccello','Gatto','Cervo',
               'Cane','Rana','Cavallo','Nave','Camion']

# Predizioni su alcune immagini
predictions = model.predict(x_test[:10])

plt.figure(figsize=(12,4))
for i in range(10):
    plt.subplot(2,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(x_test[i])
    plt.xlabel(f"Pred: {class_names[np.argmax(predictions[i])]}")
plt.show()
