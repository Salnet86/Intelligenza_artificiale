# =========================================================
# DNN per Previsione Temperatura
# Librerie necessarie: numpy, pandas, scikit-learn, tensorflow
# =========================================================

import numpy as np                 # Gestione dei numeri e array
import pandas as pd                # Gestione dei dati in DataFrame
from sklearn.model_selection import train_test_split  # Per dividere i dati in train/test
from sklearn.preprocessing import MinMaxScaler       # Normalizzazione dei dati
from tensorflow import keras       # Libreria principale per reti neurali
from tensorflow.keras import layers  # Layer della rete neurale

# =========================================================
# 1. Creiamo dati di esempio
# Supponiamo di avere: ora, umidità, pressione -> temperatura
# =========================================================

np.random.seed(0)  # Fissa il seme per numeri casuali, risultati riproducibili
ore = np.random.randint(0, 24, 500)         # Ore del giorno (0-23)
umidita = np.random.randint(20, 100, 500)   # Umidità % (20-100)
pressione = np.random.randint(980, 1050, 500) # Pressione atmosferica (hPa)

# Generiamo la temperatura con una formula artificiale + rumore casuale
temperatura = 10 + 0.5 * ore - 0.2 * (umidita/10) + 0.1 * (pressione - 1000) + np.random.randn(500)

# Creiamo un DataFrame per organizzare i dati
data = pd.DataFrame({
    'ora': ore,
    'umidita': umidita,
    'pressione': pressione,
    'temperatura': temperatura
})

# =========================================================
# 2. Separiamo input (X) e output (y)
# =========================================================
X = data[['ora', 'umidita', 'pressione']]  # Input della rete
y = data['temperatura']                    # Output target

# =========================================================
# 3. Normalizzazione dei dati
# =========================================================
# La normalizzazione aiuta la rete a imparare meglio (valori tra 0 e 1)
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)  # Trasforma X in valori normalizzati

# =========================================================
# 4. Suddividiamo in dati di addestramento e test
# =========================================================
# random_state=42 serve a rendere la divisione sempre uguale ad ogni esecuzione
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# =========================================================
# 5. Costruzione della rete neurale (DNN)
# =========================================================
model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(3,)),  # Primo layer nascosto con 64 neuroni
    layers.Dense(64, activation='relu'),                    # Secondo layer nascosto con 64 neuroni
    layers.Dense(1)                                         # Layer di output (temperatura)
])

# =========================================================
# 6. Compilazione del modello
# =========================================================
# optimizer='adam' -> metodo di ottimizzazione
# loss='mse' -> errore quadratico medio (per regressione)
# metrics=['mae'] -> metrica di valutazione (errore medio assoluto)
model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# =========================================================
# 7. Addestramento della rete
# =========================================================
# epochs=100 -> numero di volte che la rete vede tutti i dati
# validation_data=(X_test, y_test) -> valutazione durante l'addestramento
history = model.fit(X_train, y_train, epochs=100, validation_data=(X_test, y_test), verbose=0)

# =========================================================
# 8. Valutazione del modello
# =========================================================
loss, mae = model.evaluate(X_test, y_test)
print(f"Errore medio assoluto (MAE): {mae:.2f} °C")

# =========================================================
# 9. Predizione su un nuovo dato
# =========================================================
# Supponiamo: ora=14, umidità=60%, pressione=1010 hPa
nuovo_dato = np.array([[14, 60, 1010]])
nuovo_dato_scaled = scaler.transform(nuovo_dato)  # Normalizziamo come prima
pred_temp = model.predict(nuovo_dato_scaled)
print(f"Temperatura prevista: {pred_temp[0][0]:.2f} °C")
