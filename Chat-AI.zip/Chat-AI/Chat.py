Autori:
Valentina,
Salvatore,
Paola,
Fabrizzio,
Tutor Rizzo
Stagisti Corso Addetto alla logistica automatica ambito IOT








# Importiamo i moduli necessari da Flask
from flask import Flask, request, jsonify


# Creiamo l'istanza di un'applicazione Flask
app = Flask(__name__)


# Definiamo un vocabolario (insieme di parole conosciute dal bot)
# Queste sono le parole che il bot riconoscerà nel messaggio dell'utente
vocab = ['ciao', 'come', 'stai', 'bene', 'male', 'aiuto']


# Funzione one_hot che trasforma una parola in un vettore one-hot
# La funzione prende come parametro la parola da codificare
# Il vettore one-hot è un array di zeri, con il valore 1 alla posizione corrispondente alla parola nel vocab
def one_hot(word):
    vec = [0] * len(vocab) # Inizializziamo un array di zeri della lunghezza del vocab
    if word in vocab: # Se la parola è nel vocabolario
        vec[vocab.index(word)] = 1 # Mettiamo 1 nella posizione corrispondente alla parola
    return vec # Ritorniamo il vettore one-hot


# Risposte predefinite in base alla parola riconosciuta
# Ogni parola nel vocabolario ha una risposta associata
responses = {
    'ciao': "Ciao! Come posso aiutarti oggi?",
    'come': "Sto bene, grazie! E tu?",
    'aiuto': "Dimmi pure, sono qui per aiutarti!"
}


# Definiamo la rotta '/chat' che sarà chiamata quando l'utente invia un messaggio
# Questo metodo è di tipo POST perché riceve dati (messaggio) dal client (frontend)
@app.route('/chat', methods=['POST'])
def chat():
    # Recuperiamo i dati inviati dal client
    data = request.json # Dati in formato JSON
    message = data.get('message', '').lower().split() # Separiamo le parole del messaggio


    # Risposta predefinita nel caso in cui nessuna parola conosciuta venga trovata
    response = "Non ho capito, puoi ripetere?"


    # Cicliamo su ogni parola nel messaggio
    for word in message: # 'message' è una lista di parole
        # Se la parola è nel vocabolario, restituiamo la risposta associata
        if word in responses:
            response = responses[word] # Assegniamo la risposta associata alla parola trovata
            break # Esci dal ciclo appena troviamo una parola corrispondente


    # Troviamo la prima parola significativa (se esiste) per calcolare il one-hot
    first_word = next((w for w in message if w in vocab), None) # Trova la prima parola nel vocab
    vec = one_hot(first_word) if first_word else [0] * len(vocab) # Se c'è una parola, crea il vettore one-hot


    # Restituiamo la risposta del bot e il vettore one-hot come JSON
    return jsonify({
        'response': response, # Risposta generata dal bot
        'one_hot': vec # Vettore one-hot per la prima parola trovata
    })


# Avvio dell'app Flask
if __name__ == '__main__':
    app.run(debug=True) # Avvia l'app in modalità di debug

