<?php
$home = getenv('HOME') ?: '/root';
$keyfile = $home . '/.gemini_key';
$model = 'gemini-1.5-flash';

// Solo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Only POST allowed']);
    exit;
}

// Leggi body
$raw = file_get_contents('php://input');
if (!$raw) { 
    http_response_code(400);
    echo json_encode(['error'=>'Empty body']);
    exit; 
}

// Chiave
if (!file_exists($keyfile)) { 
    http_response_code(500);
    echo json_encode(['error'=>'Key not found']); 
    exit; 
}
$api_key = trim(file_get_contents($keyfile));
if (!$api_key) { 
    http_response_code(500);
    echo json_encode(['error'=>'Key empty']); 
    exit; 
}

// Endpoint Gemini
$target = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . urlencode($api_key);

// cURL
$ch = curl_init($target);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, $raw);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

$result = curl_exec($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_err = curl_errno($ch) ? curl_error($ch) : null;
curl_close($ch);

// Log per debug
file_put_contents($home.'/gemini_debug.log', date('Y-m-d H:i:s').' - HTTP:'.$http_status.' - Result: '.$result.PHP_EOL, FILE_APPEND);

// Se cURL fallisce
if ($result === false) {
    http_response_code(502);
    echo json_encode(['error'=>'cURL error','detail'=>$curl_err]);
    exit;
}

// Se Gemini API restituisce errore
$data = json_decode($result, true);
if(isset($data['error'])) {
    http_response_code($http_status ?: 500);
    echo json_encode(['error'=>'Google API error','detail'=>$data['error']]);
    exit;
}

// Tutto ok
http_response_code($http_status ?: 200);
header('Content-Type: application/json; charset=utf-8');
echo $result;
exit;
?>
