# Chat Gemini (via proxy) - Termux shell linux  / PHP / JS
#cerca il modello giusto di gemini e genera la chiave
## Descrizione
#TECNICHE E TECNOLOGIE AI DOCENTE ML
Questo progetto è un client web per interagire con **Gemini AI** (Generative Language API di Google) utilizzando **JavaScript e PHP** su Android tramite Termux.  

- L'interfaccia HTML permette di inviare messaggi e visualizzare le risposte di Gemini.  
- `proxy.php` funge da intermediario, gestendo la chiave API in sicurezza e comunicando con l'API di Google.  
- La chiave API è conservata in locale su Termux in `~/.gemini_key`, **mai condividere pubblicamente**.  

⚠️ Nota: Alcuni modelli Gemini, come `gemini-1.5-flash`, potrebbero non essere più disponibili. Utilizzare un modello aggiornato come `gemini-2.5-flash`.

---

## Struttura del progetto


---

## Installazione e configurazione

1. **Installare Termux** su Android:  
   [https://termux.com/](https://termux.com/)

2. **Installare PHP in Termux**:

```bash
pkg update
pkg install php

cd $HOME
mkdir pro_gemini
cd pro_gemini


echo -n "LA_TUA_CHIAVE_NUOVA" > ~/.gemini_key
chmod 600 ~/.gemini_key


cd $HOME/pro_gemini
php -S localhost:8080


http://localhost:8080/gemini.html

curl "https://generativelanguage.googleapis.com/v1beta/models?key=LA_TUA_CHIAVE_NUOVA"


