# 1. Matrice piccola di partenza (dal collo di bottiglia della U-Net)
vecchia_matrice = [
    [1, 2],
    [3, 4]
]

# 2. Misuriamo la vecchia matrice (Altezza e Larghezza)
vecchia_h = len(vecchia_matrice)       # Altezza = 2
vecchia_w = len(vecchia_matrice[0])    # Larghezza = 2

# 3. Calcoliamo le nuove dimensioni (raddoppio per 2)
nuova_h = vecchia_h * 2  # Diventa 4
nuova_w = vecchia_w * 2  # Diventa 4

# 4. Creiamo la nuova matrice vuota (tela) 4x4 piena di zeri
nuova_matrice = [[0 for _ in range(nuova_w)] for _ in range(nuova_h)]

# 5. PRIMO BLOCCO DI CICLI: Inserimento degli zeri (Upsampling)
for i in range(vecchia_h):
    for j in range(vecchia_w):
        # Moltiplichiamo per 2 per lasciare lo spazio vuoto in mezzo
        nuova_matrice[i * 2][j * 2] = vecchia_matrice[i][j]

print("--- 1. Matrice dopo l'inserimento degli zeri ---")
for riga in nuova_matrice:
    print(riga)


# 6. SECONDO BLOCCO DI CICLI: La convoluzione/pulizia (Il Filtro)
# Definiamo un semplice filtro (Kernel) di esempio 2x2 o 3x3
# Questo filtro scorrerà sulla matrice allargata per riempire gli zeri
kernel_h = 2
kernel_w = 2

# Creiamo una matrice finale dove metteremo i risultati ripuliti
# (Dimensione adattata allo scorrimento del filtro)
uscita_h = nuova_h - kernel_h + 1
uscita_w = nuova_w - kernel_w + 1
matrice_pulita = [[0 for _ in range(uscita_w)] for _ in range(uscita_h)]

# I secondi due cicli for per far muovere il filtro
for i in range(uscita_h):
    for j in range(uscita_w):
        
        # Qui dentro il filtro "legge" la sottomatrice della nuova_matrice
        # e calcola la somma ponderata per ripulire gli zeri
        somma = 0
        for ki in range(kernel_h):
            for kj in range(kernel_w):
                # Esempio di moltiplicazione pixel * peso del filtro
                pixel = nuova_matrice[i + ki][j + kj]
                somma += pixel # (qui andrebbe moltiplicato per il peso del kernel)
                
        matrice_pulita[i][j] = somma

print("\n--- 2. Matrice finale dopo il filtro di pulizia ---")
for riga in matrice_pulita:
    print(riga)
    