# Definiamo un bias per il nostro filtro (può essere un numero qualsiasi, es. 0.5 o 0.0)
bias = 0.5

# Ciclo esterno per muovere il filtro riga per riga (stride)
for i in range(0, nuova_h - kernel_h + 1, stride):
    for j in range(0, nuova_w - kernel_w + 1, stride):
        
        somma = 0
        
        # Cicli interni per scorrere dentro il kernel e la sottomatrice
        for ki in range(kernel_h):
            for kj in range(kernel_w):
                # Moltiplicazione elemento della matrice allargata * peso del kernel
                valore_pixel = nuova_matrice[i + ki][j + kj]
                peso = kernel[ki][kj]
                somma += valore_pixel * peso
                
        # AGGIUNGIAMO IL BIAS ALLA SOMMA FINALE!
        risultato_con_bias = somma + bias
        
        # Salviamo il risultato finale nella matrice di uscita
        matrice_pulita[i // stride][j // stride] = risultato_con_bias
        