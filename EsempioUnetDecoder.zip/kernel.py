# 1. Matrice piccola di partenza (collo di bottiglia)
vecchia_matrice = [
    [1, 2],
    [3, 4]
]

# 2. Misuriamo la vecchia matrice
vecchia_h = len(vecchia_matrice)
vecchia_w = len(vecchia_matrice[0])

# 3. Calcoliamo le nuove dimensioni (raddoppio)
nuova_h = vecchia_h * 2  # 4
nuova_w = vecchia_w * 2  # 4

# 4. Creiamo la nuova matrice vuota 4x4 piena di zeri
nuova_matrice = [[0 for _ in range(nuova_w)] for _ in range(nuova_h)]

# 5. Inserimento degli zeri (Upsampling geometrico)
for i in range(vecchia_h):
    for j in range(vecchia_w):
        nuova_matrice[i * 2][j * 2] = vecchia_matrice[i][j]

print("--- 1. Matrice con gli zeri (4x4) ---")
for riga in nuova_matrice:
    print(riga)


# 6. DEFINIZIONE DEL KERNEL (I pesi)
# Scegliamo un filtro 2x2 con dei pesi di esempio
kernel = [
    [1, 1],
    [1, 1]
]
kernel_h = len(kernel)
kernel_w = len(kernel[0])

# 7. CALCOLO DELLA CONVOLUZIONE CON LO STRIDE
# Definiamo lo stride (passo di movimento del filtro)
stride = 1

# Calcoliamo le dimensioni della matrice finale in base allo scorrimento
uscita_h = ((nuova_h - kernel_h) // stride) + 1
uscita_w = ((nuova_w - kernel_w) // stride) + 1

matrice_pulita = [[0 for _ in range(uscita_w)] for _ in range(uscita_h)]

# Ciclo esterno per muovere il filtro riga per riga (stride)
for i in range(0, nuova_h - kernel_h + 1, stride):
    for j in range(0, nuova_w - kernel_w + 1, stride):
        
        somma = 0
        
        # Cicli interni per scorrere dentro il kernel e la sottomatrice
        for ki in range(kernel_h):
            for kj in range(kernel_w):
                # Moltiplicazione elemento della matrice allargata * peso del kernel
                valore_pixel = nuova_matrice[i + ki][j + kj]
                peso = kernel[ki][kj]
                somma += valore_pixel * peso
                
        # Salviamo il risultato calcolato nella nuova matrice di uscita
        matrice_pulita[i // stride][j // stride] = somma

print("\n--- 2. Matrice finale dopo la convoluzione con i pesi ---")
for riga in matrice_pulita:
    print(riga)
