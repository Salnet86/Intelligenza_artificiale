# 1. Matrice piccola di partenza (collo di bottiglia)
vecchia_matrice = [
    [1, 2],
    [3, 4]
]

# 2. Misuriamo la vecchia matrice
vecchia_h = len(vecchia_matrice)
vecchia_w = len(vecchia_matrice[0])

# 3. Calcoliamo le nuove dimensioni (raddoppio)
nuova_h = vecchia_h * 2  # 4
nuova_w = vecchia_w * 2  # 4

# 4. Creiamo la nuova matrice vuota 4x4 piena di zeri
nuova_matrice = [[0 for _ in range(nuova_w)] for _ in range(nuova_h)]

# 5. Inserimento degli zeri (Upsampling geometrico)
for i in range(vecchia_h):
    for j in range(vecchia_w):
        nuova_matrice[i * 2][j * 2] = vecchia_matrice[i][j]
        print(nuova_matrice)