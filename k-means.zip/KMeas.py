import numpy as np

# Dati: 6 punti 2D
points = np.array([
    [1, 1],
    [1.5, 2],
    [3, 4],
    [5, 7],
    [3.5, 5],
    [4.5, 5]
])

K = 2  # numero di cluster
max_iters = 10  # massimo iterazioni

# 1. Inizializza i centroidi scegliendo casualmente K punti
np.random.seed(42)  # per riproducibilità
initial_indices = np.random.choice(len(points), K, replace=False)
centroids = points[initial_indices]

print("Centroidi iniziali:")
print(centroids)

for i in range(max_iters):
    # 2. Calcola distanze tra ogni punto e ogni centroide
    distances = np.linalg.norm(points[:, np.newaxis] - centroids, axis=2)  # shape (N punti, K centroidi)
    
    # 3. Assegna ogni punto al cluster più vicino
    clusters = np.argmin(distances, axis=1)
    
    # 4. Aggiorna i centroidi calcolando la media dei punti assegnati
    new_centroids = np.array([points[clusters == k].mean(axis=0) if np.any(clusters == k) else centroids[k]
                              for k in range(K)])
    
    print(f"\nIterazione {i+1}")
    print("Assegnazioni cluster:", clusters)
    print("Nuovi centroidi:")
    print(new_centroids)
    
    # 5. Controlla se i centroidi sono cambiati, se no ferma
    if np.allclose(centroids, new_centroids):
        print("Convergenza raggiunta.")
        break
    centroids = new_centroids
