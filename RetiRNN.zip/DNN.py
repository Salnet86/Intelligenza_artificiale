# Docente: Alessandra  
# Lezioni di Informatica — AI — Rete DNN con Keras

import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD

# Dati di input (temperatura normalizzata /100)
x = np.array([[0.20], [0.30], [0.80], [0.12]])
y = x.copy()  # target = stesso valore (autoassociatore)

# Costruzione modello DNN
model = Sequential()
model.add(Dense(8, activation='relu', input_shape=(1,)))
model.add(Dense(1, activation='linear'))  # output lineare

# Compilazione
model.compile(optimizer=SGD(learning_rate=0.1), loss='mse')

# Addestramento
history = model.fit(x, y, epochs=200, verbose=0)

# Predizione
pred = model.predict(x)

print("Input:", y.flatten())
print("Output previsto:", pred.flatten())
