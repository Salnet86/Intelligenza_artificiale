import openai

# Imposta la tua chiave API
openai.api_key = 'la_tua_chiave_api'

# Funzione per inviare una richiesta al modello GPT
def chat_with_gpt(prompt):
    response = openai.Completion.create(
        engine="gpt-3.5-turbo",  # O "gpt-4" se hai accesso
        prompt=prompt,
        max_tokens=150,  # Puoi regolare il numero di token
        n=1,  # Numero di risposte generate
        stop=None,  # Puoi impostare un carattere di stop se vuoi limitare la risposta
        temperature=0.7  # Imposta la creatività delle risposte (0.0-1.0)
    )
    
    # Restituisci la risposta generata
    return response.choices[0].text.strip()

# Esegui la funzione con un prompt
prompt = "Ciao, come stai?"
response = chat_with_gpt(prompt)
print("Risposta:", response)
