from flask import Flask, render_template, request
from openai import OpenAI
import os

app = Flask(__name__)

# In alternativa puoi mettere la chiave in variabile ambiente
client = OpenAI(api_key="LA_TUA_API_KEY")

@app.route("/", methods=["GET", "POST"])
def index():
    corrected_text = ""
    if request.method == "POST":
        user_text = request.form["user_text"]

        # Chiamata API a ChatGPT
        response = client.chat.completions.create(
            model="gpt-4o-mini",  # veloce ed economico
            messages=[
                {"role": "system", "content": "Sei un assistente che corregge e migliora testi in italiano."},
                {"role": "user", "content": f"Correggi e migliora questo testo: {user_text}"}
            ]
        )

        corrected_text = response.choices[0].message.content

    return render_template("index.html", corrected_text=corrected_text)

if __name__ == "__main__":
    app.run(debug=True)
