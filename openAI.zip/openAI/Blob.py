import openai

# Imposta la tua chiave API
openai.api_key = 'la_tua_chiave_api'

# Funzione per generare un articolo per il blog
def genera_articolo_blog(titolo, descrizione, lunghezza=500):
    prompt = f"Scrivi un articolo di {lunghezza} parole intitolato '{titolo}' sul tema: {descrizione}."

    # Chiamata all'API di OpenAI
    response = openai.Completion.create(
        engine="gpt-3.5-turbo",  # Puoi usare "gpt-4" se hai accesso
        prompt=prompt,
        max_tokens=lunghezza * 2,  # Calcola una lunghezza adeguata per l'articolo
        temperature=0.7,  # La creatività della risposta
        n=1,  # Numero di risposte
        stop=["\n", ".", ";"]  # Punti di stop per evitare risposte troppo lunghe
    )

    # Restituisci il testo dell'articolo
    return response.choices[0].text.strip()

# Esegui la funzione con un titolo e una descrizione
titolo = "Migliorare la SEO del tuo blog: Strategie e Tecniche"
descrizione = "Un'analisi delle migliori pratiche SEO per ottimizzare il posizionamento di un blog sui motori di ricerca"
articolo = genera_articolo_blog(titolo, descrizione)

print("Articolo generato:\n")
print(articolo)
