const API_KEY = 'INSERISCI_LA_TUA_API_KEY_DI_GEMINI'; // Sostituisci qui

const chatBox = document.getElementById('chat');
const form = document.getElementById('form');
const input = document.getElementById('input');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const userMessage = input.value.trim();
  if (!userMessage) return;

  appendMessage('user', userMessage);
  input.value = '';

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: userMessage }] }]
      })
    });

    const data = await response.json();

    if (data.candidates && data.candidates.length > 0) {
      const botMessage = data.candidates[0].content.parts[0].text;
      appendMessage('bot', botMessage);
    } else {
      appendMessage('bot', '❌ Nessuna risposta ricevuta.');
    }
  } catch (err) {
    console.error(err);
    appendMessage('bot', '❌ Errore durante la richiesta.');
  }
});

function appendMessage(sender, text) {
  const div = document.createElement('div');
  div.className = 'msg';
  div.innerHTML = `<span class="${sender}">${sender === 'user' ? '👤 Tu' : '🤖 Gemini'}:</span> ${text}`;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}
