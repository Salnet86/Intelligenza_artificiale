import random
import pickle
import os

# =========================
# PARAMETRI
# =========================
rate = 0.7
neuroni = 2
temperatura = [20, 30, 50, 100]
umidita = [19, 20, 40, 60]
epoca = 10

target_temp = 1
target_umidita = 1

# Normalizzazione input
temperatura_norm = [t / 100 for t in temperatura]
umidita_norm = [u / 100 for u in umidita]

# Funzioni ReLU
def Relu(x):
    return max(0, x)

def Relu_deriv(x):
    return 1 if x > 0 else 0

# =========================
# MODALITÀ
# =========================
modalita = input("Modalità (train/inferenza): ").strip().lower()

# =========================
# CARICAMENTO PESI E BIAS
# =========================
if os.path.exists("rete_salvata.pkl"):
    with open("rete_salvata.pkl", "rb") as f:
        dati = pickle.load(f)
        pesi = dati["pesi"]
        bias = dati["bias"]
    print("Rete caricata dai dati salvati.")
else:
    pesi = [random.uniform(0, 0.1) for _ in range(neuroni)]
    bias = [random.uniform(0, 0.2) for _ in range(neuroni)]
    print("Nuova rete inizializzata.")

# =========================
# ADDDESTRAMENTO
# =========================
if modalita == "train":
    for ep in range(epoca):
        print(f"\n--- Epoca {ep+1} ---")
        for n in range(neuroni):
            # Temperatura
            for temp_norm in temperatura_norm:
                z1 = pesi[n] * temp_norm + bias[n]
                a1 = Relu(z1)
                errore_temp = target_temp - a1
                delta_temp = errore_temp * Relu_deriv(z1)
                pesi[n] += rate * delta_temp * temp_norm
                bias[n] += rate * delta_temp
                print(f"Temp={temp_norm:.2f}, Errore={errore_temp:.3f}")

            # Umidità
            for umid_norm in umidita_norm:
                z2 = pesi[n] * umid_norm + bias[n]
                a2 = Relu(z2)
                errore_umidita = target_umidita - a2
                delta_umidita = errore_umidita * Relu_deriv(z2)
                pesi[n] += rate * delta_umidita * umid_norm
                bias[n] += rate * delta_umidita
                print(f"Umidita={umid_norm:.2f}, Errore={errore_umidita:.3f}")

    # Salvataggio pesi e bias
    with open("rete_salvata.pkl", "wb") as f:
        pickle.dump({"pesi": pesi, "bias": bias}, f)
    print("\nRete salvata su file!")

# =========================
# INFERENZA
# =========================
elif modalita == "inferenza":
    print("\n--- Inferenza ---")
    for n in range(neuroni):
        for temp_norm in temperatura_norm:
            z1 = pesi[n] * temp_norm + bias[n]
            a1 = Relu(z1)
            print(f"Temp={temp_norm:.2f}, Output={a1:.3f}")
        for umid_norm in umidita_norm:
            z2 = pesi[n] * umid_norm + bias[n]
            a2 = Relu(z2)
            print(f"Umidita={umid_norm:.2f}, Output={a2:.3f}")

else:
    print("Modalità non valida! Inserisci 'train' o 'inferenza'.")
