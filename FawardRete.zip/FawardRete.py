import random

# =========================
# PARAMETRI INIZIALI
# =========================
rate = 0.7              # Learning rate
neuroni = 2             # Numero di neuroni
temperatura = [20, 30, 50, 100]  # Input temperatura
umidita = [19, 20, 40, 60]       # Input umidità
epoca = 20              # Numero di epoche di addestramento

target_temp = 1         # Target normalizzato per temperatura
target_umidita = 1      # Target normalizzato per umidità

# =========================
# NORMALIZZAZIONE INPUT
# =========================
# La rete lavora meglio con valori piccoli (0-1)
temperatura_norm = [t / 100 for t in temperatura]
umidita_norm = [u / 100 for u in umidita]

# =========================
# FUNZIONI DI ATTIVAZIONE
# =========================
def Relu(x):
    """Funzione ReLU"""
    return max(0, x)

def Relu_deriv(x):
    """Derivata della ReLU per calcolo delta"""
    return 1 if x > 0 else 0

# =========================
# INIZIALIZZAZIONE PESI E BIAS
# =========================
# Una volta sola prima del ciclo di epoche
pesi = [random.uniform(0, 0.1) for _ in range(neuroni)]
bias = [random.uniform(0, 0.2) for _ in range(neuroni)]

# =========================
# CICLO SULLE EPOCHE
# =========================
for ep in range(epoca):
    print(f"\n--- Epoca {ep+1} ---")
    for n in range(neuroni):
        # =========================
        # CALCOLO PER TEMPERATURA
        # =========================
        for temp_norm in temperatura_norm:
            # Forward pass: output lineare + ReLU
            z1 = pesi[n] * temp_norm + bias[n]
            a1 = Relu(z1)

            # Calcolo errore e delta
            errore_temp = target_temp - a1
            delta_temp = errore_temp * Relu_deriv(z1)

            # Aggiornamento pesi e bias (Stochastic Gradient Descent)
            pesi[n] += rate * delta_temp * temp_norm
            bias[n] += rate * delta_temp

            # Stampa solo input normalizzato e errore
            print(f"Temp={temp_norm:.2f}, Errore={errore_temp:.3f}")

        # =========================
        # CALCOLO PER UMIDITÀ
        # =========================
        for umid_norm in umidita_norm:
            # Forward pass: output lineare + ReLU
            z2 = pesi[n] * umid_norm + bias[n]
            a2 = Relu(z2)

            # Calcolo errore e delta
            errore_umidita = target_umidita - a2
            delta_umidita = errore_umidita * Relu_deriv(z2)

            # Aggiornamento pesi e bias
            pesi[n] += rate * delta_umidita * umid_norm
            bias[n] += rate * delta_umidita

            # Stampa solo input normalizzato e errore
            print(f"Umidita={umid_norm:.2f}, Errore={errore_umidita:.3f}")
