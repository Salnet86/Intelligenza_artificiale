# Docente: Alessandra  
# Lezioni di Informatica — AI — Softmax con prezzi borse

import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation
from tensorflow.keras.optimizers import SGD

# Dati di input: prezzi borse
prezzi = np.array([[12.7], [8.0], [7.0], [2.7], [6.8]])

# Target: vogliamo semplicemente trasformare in probabilità con softmax
# In Keras, softmax si applica all'ultimo layer
model = Sequential()
model.add(Dense(5, input_shape=(1,), activation='softmax'))

# Compilazione (loss non rilevante qui, solo forward)
model.compile(optimizer=SGD(learning_rate=0.1), loss='categorical_crossentropy')

# Predizione (softmax output)
probabilità = model.predict(prezzi)

print("Prezzi:", prezzi.flatten())
print("Probabilità softmax per ogni prezzo:")
print(probabilità)
print("Somma probabilità per ogni input (dovrebbe essere 1):", probabilità.sum(axis=1))
