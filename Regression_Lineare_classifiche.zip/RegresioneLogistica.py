# Docente: Alessandra  
# Lezioni di Informatica — AI — Regressione Logistica con scikit-learn

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Dati di input: prezzi borse
prezzi = np.array([12.7, 8.0, 7.0, 2.7, 6.8]).reshape(-1, 1)

# Creiamo un target binario: se il prezzo è maggiore di 6, è "prezzo alto" (1), altrimenti "prezzo basso" (0)
# Soglia: 6
target = np.array([1 if prezzo > 6 else 0 for prezzo in prezzi])

# Dividiamo i dati in training e test
X_train, X_test, y_train, y_test = train_test_split(prezzi, target, test_size=0.2, random_state=42)

# Creazione del modello di regressione logistica
model = LogisticRegression()

# Addestramento del modello
model.fit(X_train, y_train)

# Predizione
y_pred = model.predict(X_test)

# Calcolo dell'accuratezza
accuracy = accuracy_score(y_test, y_pred)

print("Dati di input:", prezzi.flatten())
print("Target:", target)
print("Predizioni:", y_pred)
print("Accuratezza del modello:", accuracy)
