# Docente: Alessandra  
# Lezioni di Informatica — AI — Regressione Lineare sulla probabilità di incendio

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Dati di esempio: [temperatura, umidità, vento]
# L'ultimo valore è la probabilità di incendio (target tra 0 e 1)
dati = np.array([
    [30, 40, 5, 0.1],  # temperatura 30°C, umidità 40%, vento 5 m/s, probabilità incendio 0.1
    [32, 35, 3, 0.2],  # ...
    [40, 20, 8, 0.6],
    [45, 15, 10, 0.8],
    [50, 10, 15, 0.9],
    [35, 50, 7, 0.3],
    [33, 45, 6, 0.4],
    [38, 30, 12, 0.7]
])

# Separiamo i dati in variabili indipendenti (features) e target
X = dati[:, :-1]  # temperatura, umidità, vento
y = dati[:, -1]   # probabilità incendio

# Dividiamo i dati in training e test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Creiamo il modello di regressione lineare
model = LinearRegression()

# Addestramento del modello
model.fit(X_train, y_train)

# Predizione
y_pred = model.predict(X_test)

# Calcolo dell'errore quadratico medio (MSE) per valutare la qualità della previsione
mse = mean_squared_error(y_test, y_pred)

print("Dati di input (temperatura, umidità, vento):")
print(X_test)
print("Probabilità di incendio previste:", y_pred)
print("Errore quadratico medio (MSE):", mse)
