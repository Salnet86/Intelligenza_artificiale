# ============================================================
# 📘 PORTFOLIO AVANZATO TENSORFLOW + KERAS
# Reti Neurali, Deep Learning e Visualizzazioni Training
# Autore: SalvoNet
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_iris, make_moons

# ============================================================
# 1️⃣ FUNZIONE UTILE PER GRAFICI TRAINING
# ============================================================
def plot_training(history, title="Training Loss/Accuracy"):
    plt.figure(figsize=(8,4))
    if 'loss' in history.history:
        plt.plot(history.history['loss'], label='Loss')
    if 'accuracy' in history.history:
        plt.plot(history.history['accuracy'], label='Accuracy')
    plt.title(title)
    plt.xlabel('Epoch')
    plt.ylabel('Valore')
    plt.legend()
    plt.grid(True)
    plt.show()

# ============================================================
# 2️⃣ REGRESSIONE CON RETE NEURALE
# ============================================================
print("\n================ REGRESSIONE (NN) ================\n")

X_reg = np.array([[1],[2],[3],[4],[5]], dtype=float)
y_reg = np.array([5,7,9,11,13], dtype=float)

model_reg = Sequential([
    Dense(8, input_dim=1, activation='relu'),
    Dense(4, activation='relu'),
    Dense(1)
])

model_reg.compile(optimizer=Adam(0.01), loss='mse')
history_reg = model_reg.fit(X_reg, y_reg, epochs=200, verbose=0)

y_pred_reg = model_reg.predict(X_reg)

plt.figure(figsize=(6,4))
plt.scatter(X_reg, y_reg, color='blue', label='Dati reali')
plt.plot(X_reg, y_pred_reg, color='red', label='Predizione NN')
plt.title("Regressione con Rete Neurale")
plt.xlabel("Pubblicità (k€)")
plt.ylabel("Vendite (k unità)")
plt.legend()
plt.show()

plot_training(history_reg, "Training Loss Regressione")

# ============================================================
# 3️⃣ CLASSIFICAZIONE CON RETE NEURALE (make_moons dataset)
# ============================================================
print("\n================ CLASSIFICAZIONE (NN) - 2D ================\n")

X_moons, y_moons = make_moons(n_samples=200, noise=0.2, random_state=42)
y_moons_cat = to_categorical(y_moons)

X_train, X_test, y_train, y_test = train_test_split(X_moons, y_moons_cat, test_size=0.3, random_state=42)

model_clf = Sequential([
    Dense(16, input_dim=2, activation='relu'),
    Dense(8, activation='relu'),
    Dense(2, activation='softmax')
])

model_clf.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
history_clf = model_clf.fit(X_train, y_train, epochs=200, verbose=0)

loss, accuracy = model_clf.evaluate(X_test, y_test, verbose=0)
print("Accuracy classificazione NN 2D:", accuracy)

plot_training(history_clf, "Training Loss/Accuracy Classificazione 2D")

# Visualizzazione predizioni
x_min, x_max = X_moons[:,0].min()-0.5, X_moons[:,0].max()+0.5
y_min, y_max = X_moons[:,1].min()-0.5, X_moons[:,1].max()+0.5
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.01),
                     np.arange(y_min, y_max, 0.01))
grid = np.c_[xx.ravel(), yy.ravel()]
preds = np.argmax(model_clf.predict(grid), axis=1).reshape(xx.shape)

plt.figure(figsize=(6,4))
plt.contourf(xx, yy, preds, alpha=0.3, cmap='coolwarm')
plt.scatter(X_moons[:,0], X_moons[:,1], c=y_moons, edgecolor='k', cmap='coolwarm')
plt.title("Predizioni Rete Neurale - make_moons")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.show()

# ============================================================
# 4️⃣ RETE NEURALE CON DATASET IRIS
# ============================================================
print("\n================ RETE NEURALE IRIS ================\n")

iris = load_iris()
X_iris = iris.data
y_iris = to_categorical(iris.target)

scaler = StandardScaler()
X_iris_scaled = scaler.fit_transform(X_iris)

X_train, X_test, y_train, y_test = train_test_split(X_iris_scaled, y_iris, test_size=0.3, random_state=42)

model_iris = Sequential([
    Dense(16, input_dim=4, activation='relu'),
    Dense(12, activation='relu'),
    Dense(3, activation='softmax')
])

model_iris.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
history_iris = model_iris.fit(X_train, y_train, epochs=200, verbose=0)

loss, accuracy = model_iris.evaluate(X_test, y_test, verbose=0)
print("Accuracy rete neurale Iris:", accuracy)

plot_training(history_iris, "Training Loss/Accuracy Iris")

# ============================================================
# 5️⃣ VISUALIZZAZIONE PESI NEURONALI
# ============================================================
weights = model_iris.get_weights()
print("\nPesi primo layer:\n", weights[0])
print("Bias primo layer:\n", weights[1])

# ============================================================
# 6️⃣ TEST DATI PERSONALIZZATI
# ============================================================
print("\n================ TEST DATI PERSONALIZZATI ================\n")
nuovo_input = np.array([[0.1,0.2],[0.5,0.5],[0.9,0.1]])
pred_test = np.argmax(model_clf.predict(nuovo_input), axis=1)
print("Predizioni rete classificazione 2D per nuovi input:", pred_test)

# ============================================================
# ✅ FINE PORTFOLIO AVANZATO TENSORFLOW + KERAS
# ============================================================

print("\n🔹 Demo avanzata TensorFlow + Keras completata! Tutte le reti neurali, visualizzazioni e test dati pronti.")
