# ============================================================
# 🤖 CHATBOT INTELLIGENTE - TensorFlow + Keras
# Autore: SalvoNet
# ============================================================

import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.preprocessing import LabelEncoder

# ============================================================
# 1️⃣ DATASET FITTIZIO DOMANDE / RISPOSTE
# ============================================================
dataset = [
    {"pattern": "ciao", "tag": "saluto", "response": "Ciao! Come stai?"},
    {"pattern": "buongiorno", "tag": "saluto", "response": "Buongiorno!"},
    {"pattern": "come stai", "tag": "stato", "response": "Sto bene, grazie!"},
    {"pattern": "che fai", "tag": "stato", "response": "Sto parlando con te!"},
    {"pattern": "addio", "tag": "saluto_fine", "response": "A presto!"},
    {"pattern": "grazie", "tag": "gratitudine", "response": "Di nulla!"},
    {"pattern": "chi sei", "tag": "info", "response": "Sono un chatbot basato su TensorFlow/Keras!"}
]

# Creazione liste
patterns = [d["pattern"] for d in dataset]
tags = [d["tag"] for d in dataset]
responses = [d["response"] for d in dataset]

# ============================================================
# 2️⃣ PREPROCESSING - VETTORIZZAZIONE SEMPLICE
# ============================================================
# Creiamo un vocabolario semplice
vocab = sorted(list(set(" ".join(patterns).split())))
word_index = {word: i for i, word in enumerate(vocab)}

def text_to_vector(text):
    vector = np.zeros(len(vocab))
    for word in text.split():
        if word in word_index:
            vector[word_index[word]] = 1
    return vector

X = np.array([text_to_vector(p) for p in patterns])

# Encode dei tag
le = LabelEncoder()
y_int = le.fit_transform(tags)
y = to_categorical(y_int)

# ============================================================
# 3️⃣ CREAZIONE MODELLO NEURALE
# ============================================================
model = Sequential([
    Dense(8, input_dim=len(vocab), activation='relu'),
    Dense(8, activation='relu'),
    Dense(y.shape[1], activation='softmax')
])

model.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(X, y, epochs=200, verbose=0)

# ============================================================
# 4️⃣ FUNZIONE CHAT
# ============================================================
def chatbot_response(msg):
    vec = text_to_vector(msg)
    pred = model.predict(np.array([vec]), verbose=0)
    tag_pred = le.inverse_transform([np.argmax(pred)])[0]
    # Trova prima risposta corrispondente al tag
    for d in dataset:
        if d["tag"] == tag_pred:
            return d["response"]
    return "Non ho capito."

# ============================================================
# 5️⃣ TEST CHATBOT
# ============================================================
print("\n💬 Chatbot pronto! Digita 'exit' per uscire.")
while True:
    user_input = input("Tu: ").lower()
    if user_input == "exit":
        print("Chatbot: A presto!")
        break
    print("Chatbot:", chatbot_response(user_input))
