# ============================================================
# 🤖 CHATBOT AVANZATO - Embedding + LSTM (TensorFlow/Keras)
# Autore: SalvoNet
# ============================================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Embedding
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical
from sklearn.preprocessing import LabelEncoder

# ============================================================
# 1️⃣ DATASET DOMANDE / RISPOSTE
# ============================================================
dataset = [
    {"pattern": "ciao", "tag": "saluto", "response": "Ciao! Come stai?"},
    {"pattern": "buongiorno", "tag": "saluto", "response": "Buongiorno!"},
    {"pattern": "come stai", "tag": "stato", "response": "Sto bene, grazie!"},
    {"pattern": "che fai", "tag": "stato", "response": "Sto parlando con te!"},
    {"pattern": "addio", "tag": "saluto_fine", "response": "A presto!"},
    {"pattern": "grazie", "tag": "gratitudine", "response": "Di nulla!"},
    {"pattern": "chi sei", "tag": "info", "response": "Sono un chatbot basato su LSTM!"},
    {"pattern": "puoi aiutarmi", "tag": "aiuto", "response": "Certo! Dimmi pure cosa ti serve."},
    {"pattern": "che ore sono", "tag": "info", "response": "Non posso dirti l'ora esatta, ma posso chiacchierare!"},
    {"pattern": "dimmi una barzelletta", "tag": "barzelletta", "response": "Perché il programmatore è triste? Perché ha troppi bug!"}
]

patterns = [d["pattern"].lower() for d in dataset]
tags = [d["tag"] for d in dataset]
responses = [d["response"] for d in dataset]

# ============================================================
# 2️⃣ TOKENIZZAZIONE E SEQUENZE
# ============================================================
tokenizer = Tokenizer(oov_token="<OOV>")
tokenizer.fit_on_texts(patterns)
X_seq = tokenizer.texts_to_sequences(patterns)
max_len = max(len(seq) for seq in X_seq)
X_pad = pad_sequences(X_seq, maxlen=max_len, padding='post')

# Encode dei tag
le = LabelEncoder()
y_int = le.fit_transform(tags)
y = to_categorical(y_int)

vocab_size = len(tokenizer.word_index) + 1
output_size = y.shape[1]

# ============================================================
# 3️⃣ CREAZIONE MODELLO LSTM
# ============================================================
model = Sequential([
    Embedding(input_dim=vocab_size, output_dim=16, input_length=max_len),
    LSTM(32),
    Dense(32, activation='relu'),
    Dense(output_size, activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(X_pad, y, epochs=300, verbose=0)

# ============================================================
# 4️⃣ FUNZIONE CHATBOT
# ============================================================
def chatbot_response(msg):
    seq = tokenizer.texts_to_sequences([msg.lower()])
    seq_pad = pad_sequences(seq, maxlen=max_len, padding='post')
    pred = model.predict(seq_pad, verbose=0)
    tag_pred = le.inverse_transform([np.argmax(pred)])[0]
    for d in dataset:
        if d["tag"] == tag_pred:
            return d["response"]
    return "Non ho capito."

# ============================================================
# 5️⃣ POSSIBILITÀ DI AGGIUNGERE NUOVE FRASI
# ============================================================
def add_new_phrase(msg, response):
    global dataset, X_pad, y, max_len, vocab_size, output_size
    new_tag = f"tag_{len(dataset)}"
    dataset.append({"pattern": msg.lower(), "tag": new_tag, "response": response})
    
    patterns = [d["pattern"] for d in dataset]
    tags = [d["tag"] for d in dataset]
    
    tokenizer.fit_on_texts(patterns)
    X_seq = tokenizer.texts_to_sequences(patterns)
    max_len = max(len(seq) for seq in X_seq)
    X_pad = pad_sequences(X_seq, maxlen=max_len, padding='post')
    
    le.fit(tags)
    y_int = le.transform(tags)
    y = to_categorical(y_int)
    
    vocab_size = len(tokenizer.word_index) + 1
    output_size = y.shape[1]
    
    model.fit(X_pad, y, epochs=50, verbose=0)
    print("✅ Nuova frase aggiunta e modello aggiornato!")

# ============================================================
# 6️⃣ ESECUZIONE CHATBOT
# ============================================================
print("\n💬 Chatbot LSTM pronto! Digita 'exit' per uscire.")
while True:
    user_input = input("Tu: ")
    if user_input.lower() == "exit":
        print("Chatbot: A presto!")
        break
    reply = chatbot_response(user_input)
    print("Chatbot:", reply)
    if reply.startswith("Non ho capito"):
        add_phrase = input("Vuoi aggiungere questa frase? (sì/no): ").lower()
        if add_phrase == "sì":
            new_resp = input("Inserisci la risposta corretta per questa frase: ")
            add_new_phrase(user_input, new_resp)
