# ============================================================
# 🤖 CHATBOT AVANZATO - TensorFlow + Keras
# Autore: SalvoNet
# ============================================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.preprocessing import LabelEncoder
import re

# ============================================================
# 1️⃣ DATASET DOMANDE / RISPOSTE AVANZATO
# ============================================================
dataset = [
    {"pattern": "ciao", "tag": "saluto", "response": "Ciao! Come stai?"},
    {"pattern": "buongiorno", "tag": "saluto", "response": "Buongiorno!"},
    {"pattern": "come stai", "tag": "stato", "response": "Sto bene, grazie!"},
    {"pattern": "che fai", "tag": "stato", "response": "Sto parlando con te!"},
    {"pattern": "addio", "tag": "saluto_fine", "response": "A presto!"},
    {"pattern": "grazie", "tag": "gratitudine", "response": "Di nulla!"},
    {"pattern": "chi sei", "tag": "info", "response": "Sono un chatbot basato su TensorFlow/Keras!"},
    {"pattern": "puoi aiutarmi", "tag": "aiuto", "response": "Certo! Dimmi pure cosa ti serve."},
    {"pattern": "che ore sono", "tag": "info", "response": "Non posso dirti l'ora esatta, ma posso chiacchierare!"},
    {"pattern": "dimmi una barzelletta", "tag": "barzelletta", "response": "Perché il programmatore è triste? Perché ha troppi bug!"}
]

# ============================================================
# 2️⃣ PREPROCESSING TESTO - TOKENIZZAZIONE E VETTORIZZAZIONE
# ============================================================
def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9 ]', '', text)
    return text

patterns = [clean_text(d["pattern"]) for d in dataset]
tags = [d["tag"] for d in dataset]
responses = [d["response"] for d in dataset]

# Vocabolario e mapping parole
vocab = sorted(list(set(" ".join(patterns).split())))
word_index = {word:i for i, word in enumerate(vocab)}

def text_to_vector(text):
    vec = np.zeros(len(vocab))
    for word in clean_text(text).split():
        if word in word_index:
            vec[word_index[word]] = 1
    return vec

X = np.array([text_to_vector(p) for p in patterns])

# Encode dei tag
le = LabelEncoder()
y_int = le.fit_transform(tags)
y = to_categorical(y_int)

# ============================================================
# 3️⃣ CREAZIONE MODELLO NEURALE
# ============================================================
model = Sequential([
    Dense(16, input_dim=len(vocab), activation='relu'),
    Dense(12, activation='relu'),
    Dense(y.shape[1], activation='softmax')
])

model.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(X, y, epochs=300, verbose=0)

# ============================================================
# 4️⃣ FUNZIONE CHAT CON POSSIBILITÀ DI AGGIUNGERE NUOVE FRASI
# ============================================================
def chatbot_response(msg):
    vec = text_to_vector(msg)
    pred = model.predict(np.array([vec]), verbose=0)
    tag_pred = le.inverse_transform([np.argmax(pred)])[0]
    for d in dataset:
        if d["tag"] == tag_pred:
            return d["response"]
    return "Non ho capito. Vuoi aggiungerlo come nuova frase? (sì/no)"

def add_new_phrase(msg, response):
    global dataset, X, y
    new_tag = f"tag_{len(dataset)}"
    dataset.append({"pattern": msg, "tag": new_tag, "response": response})
    # Aggiorna vocabolario e vettori
    if any(word not in vocab for word in msg.split()):
        new_words = [w for w in msg.split() if w not in vocab]
        vocab.extend(new_words)
        for i, word in enumerate(new_words):
            word_index[word] = len(word_index)
    X = np.array([text_to_vector(d["pattern"]) for d in dataset])
    y_int = le.fit_transform([d["tag"] for d in dataset])
    y = to_categorical(y_int)
    # Riaddestra velocemente il modello
    model.fit(X, y, epochs=50, verbose=0)
    print("✅ Nuova frase aggiunta e modello aggiornato!")

# ============================================================
# 5️⃣ ESECUZIONE CHATBOT
# ============================================================
print("\n💬 Chatbot avanzato pronto! Digita 'exit' per uscire.")
while True:
    user_input = input("Tu: ").lower()
    if user_input == "exit":
        print("Chatbot: A presto!")
        break
    reply = chatbot_response(user_input)
    print("Chatbot:", reply)
    if reply.startswith("Non ho capito"):
        add_phrase = input("Vuoi aggiungere questa frase? (sì/no): ").lower()
        if add_phrase == "sì":
            new_resp = input("Inserisci la risposta corretta per questa frase: ")
            add_new_phrase(user_input, new_resp)
