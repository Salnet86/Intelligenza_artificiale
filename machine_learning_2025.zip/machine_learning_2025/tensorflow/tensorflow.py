# ============================================================
# 📘 PORTFOLIO TENSORFLOW + KERAS - RETI NEURALI E DEEP LEARNING
# Autore: SalvoNet
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_iris

# ============================================================
# 1️⃣ REGRESSIONE CON RETE NEURALE
# ============================================================

print("\n================ REGRESSIONE (NN) ================\n")

X_reg = np.array([[1],[2],[3],[4],[5]], dtype=float)
y_reg = np.array([5,7,9,11,13], dtype=float)

model_reg = Sequential([
    Dense(8, input_dim=1, activation='relu'),
    Dense(4, activation='relu'),
    Dense(1)
])

model_reg.compile(optimizer=Adam(0.01), loss='mse')
model_reg.fit(X_reg, y_reg, epochs=200, verbose=0)

y_pred_reg = model_reg.predict(X_reg)
print("Predizioni regressione NN:", y_pred_reg.flatten())

plt.figure(figsize=(6,4))
plt.scatter(X_reg, y_reg, color='blue', label='Dati reali')
plt.plot(X_reg, y_pred_reg, color='red', label='Predizione NN')
plt.title("Regressione con Rete Neurale")
plt.xlabel("Pubblicità (k€)")
plt.ylabel("Vendite (k unità)")
plt.legend()
plt.show()

# ============================================================
# 2️⃣ CLASSIFICAZIONE CON RETE NEURALE
# ============================================================

print("\n================ CLASSIFICAZIONE (NN) ================\n")

X_class = np.array([[0,0],[0,1],[1,0],[1,1],[0.5,0.5],[0.2,0.8],[0.8,0.2]])
y_class = np.array([0,1,1,2,1,1,1])
y_class_cat = to_categorical(y_class, 3)

X_train, X_test, y_train, y_test = train_test_split(X_class, y_class_cat, test_size=0.3, random_state=42)

model_clf = Sequential([
    Dense(8, input_dim=2, activation='relu'),
    Dense(6, activation='relu'),
    Dense(3, activation='softmax')
])

model_clf.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
model_clf.fit(X_train, y_train, epochs=200, verbose=0)

loss, accuracy = model_clf.evaluate(X_test, y_test, verbose=0)
print("Accuracy classificazione NN:", accuracy)

y_pred_class = model_clf.predict(X_test)
y_pred_labels = np.argmax(y_pred_class, axis=1)
print("Predizioni classi test:", y_pred_labels)

# ============================================================
# 3️⃣ RETE NEURALE CON DATASET IRIS
# ============================================================

print("\n================ RETE NEURALE IRIS ================\n")

iris = load_iris()
X_iris = iris.data
y_iris = to_categorical(iris.target)

scaler = StandardScaler()
X_iris_scaled = scaler.fit_transform(X_iris)

X_train, X_test, y_train, y_test = train_test_split(X_iris_scaled, y_iris, test_size=0.3, random_state=42)

model_iris = Sequential([
    Dense(16, input_dim=4, activation='relu'),
    Dense(12, activation='relu'),
    Dense(3, activation='softmax')
])

model_iris.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
model_iris.fit(X_train, y_train, epochs=200, verbose=0)

loss, accuracy = model_iris.evaluate(X_test, y_test, verbose=0)
print("Accuracy rete neurale Iris:", accuracy)

# ============================================================
# 4️⃣ VISUALIZZAZIONE PESI NEURONALI
# ============================================================

weights = model_iris.get_weights()
print("\nPesi primo layer:\n", weights[0])
print("Bias primo layer:\n", weights[1])

# ============================================================
# ✅ FINE PORTFOLIO TENSORFLOW + KERAS
# ============================================================

print("\n🔹 Demo TensorFlow + Keras completata! Regressione, classificazione e Deep Learning pronti.")
