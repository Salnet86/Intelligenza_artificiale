# ============================================================
# 📘 MEGA PORTFOLIO PYTHON - DATA ANALYSIS & MACHINE LEARNING
# NumPy + Pandas + Matplotlib + SciPy + scikit-learn + TensorFlow/Keras
# Autore: SalvoNet
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats, optimize, integrate, interpolate, linalg
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.datasets import load_iris, make_blobs, make_moons
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical

# ============================================================
# 1️⃣ NUMPY - Array e algebra lineare
# ============================================================
print("\n================ NUMPY ================\n")
v = np.array([1,2,3,4])
m = np.array([[1,2],[3,4]])
print("Vettore 1D:", v)
print("Matrice 2D:\n", m)
print("Prodotto scalare:", np.dot(m,m))
print("Inversa A:\n", np.linalg.inv(m))
print("Determinante A:", np.linalg.det(m))

# ============================================================
# 2️⃣ PANDAS + MATPLOTLIB - Analisi vendite
# ============================================================
print("\n================ PANDAS + MATPLOTLIB ================\n")
dati = {"Mese":["Gen","Feb","Mar","Apr","Mag","Giu"],
        "Prod_A":[100,120,90,150,200,180],
        "Prod_B":[80,110,130,160,170,190],
        "Prod_C":[60,70,100,120,140,160]}
df = pd.DataFrame(dati)
df["Totale"] = df["Prod_A"] + df["Prod_B"] + df["Prod_C"]
print(df)

plt.figure(figsize=(8,5))
plt.plot(df["Mese"], df["Prod_A"], label="Prod_A", marker="o")
plt.plot(df["Mese"], df["Prod_B"], label="Prod_B", marker="o")
plt.plot(df["Mese"], df["Prod_C"], label="Prod_C", marker="o")
plt.title("Vendite Prodotti")
plt.legend()
plt.show()

plt.figure(figsize=(8,5))
plt.bar(df["Mese"], df["Totale"], color="skyblue")
plt.title("Vendite Totali")
plt.show()

plt.figure(figsize=(6,6))
plt.pie([df["Prod_A"].sum(), df["Prod_B"].sum(), df["Prod_C"].sum()],
        labels=["Prod_A","Prod_B","Prod_C"], autopct="%1.1f%%", startangle=90)
plt.title("Percentuale vendite")
plt.show()

# ============================================================
# 3️⃣ SCIPY - Statistica, ottimizzazione, integrazione
# ============================================================
print("\n================ SCIPY ================\n")
vendi = np.array([50,60,55,30,40,45,70,65])
print("Media:", np.mean(vendi))
print("Skewness:", stats.skew(vendi))
t_stat, p_value = stats.ttest_1samp(vendi, 50)
print("T-test:", t_stat, p_value)
res = optimize.minimize(lambda x: (x-5)**2+10, x0=0)
print("Minimo funzione:", res.x)
area, _ = integrate.quad(lambda x: 50+10*np.sin(x), 0, np.pi)
print("Integrazione vendite:", area)
f_interp = interpolate.interp1d([1,2,3,4,5],[50,60,55,70,65], kind="linear")
print("Interpolazione 2.5:", f_interp(2.5))
A = np.array([[2,1],[1,2]])
b = np.array([1,2])
print("Soluzione Ax=b:", linalg.solve(A,b))

# ============================================================
# 4️⃣ SCIKIT-LEARN - Regressione, classificazione, clustering, PCA
# ============================================================
print("\n================ SCIKIT-LEARN ================\n")

# Regressione
X_reg = np.array([[1],[2],[3],[4],[5]])
y_reg = np.array([5,7,9,11,13])
reg = LinearRegression()
reg.fit(X_reg,y_reg)
print("Predizioni Regressione:", reg.predict(X_reg))

# Classificazione
iris = load_iris()
X_iris, y_iris = iris.data, iris.target
y_cat = to_categorical(y_iris)
X_train, X_test, y_train, y_test = train_test_split(X_iris, y_cat, test_size=0.3, random_state=42)
clf = LogisticRegression(max_iter=200)
clf.fit(X_iris, y_iris)
print("Accuracy Logistic Regression:", accuracy_score(y_iris, clf.predict(X_iris)))

# Clustering
X_blob, _ = make_blobs(n_samples=100, centers=3, random_state=42)
kmeans = KMeans(n_clusters=3)
kmeans.fit(X_blob)
print("Cluster centri:", kmeans.cluster_centers_)

# PCA
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_iris)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
print("Varianza PCA:", pca.explained_variance_ratio_)

# ============================================================
# 5️⃣ TENSORFLOW + KERAS AVANZATO
# ============================================================
print("\n================ TENSORFLOW + KERAS ================\n")

def plot_history(history, title="Training"):
    plt.figure(figsize=(8,4))
    plt.plot(history.history.get('loss',[]), label='Loss')
    plt.plot(history.history.get('accuracy',[]), label='Accuracy')
    plt.title(title)
    plt.xlabel('Epoch')
    plt.ylabel('Valore')
    plt.legend()
    plt.grid(True)
    plt.show()

# Regressione NN
X_reg_tf = np.array([[1],[2],[3],[4],[5]], dtype=float)
y_reg_tf = np.array([5,7,9,11,13], dtype=float)
model_reg_tf = Sequential([Dense(8,input_dim=1,activation='relu'), Dense(4,activation='relu'), Dense(1)])
model_reg_tf.compile(Adam(0.01), loss='mse')
history_reg_tf = model_reg_tf.fit(X_reg_tf, y_reg_tf, epochs=200, verbose=0)
y_pred_tf = model_reg_tf.predict(X_reg_tf)
plot_history(history_reg_tf, "Regressione NN")

# Classificazione 2D (make_moons)
X_moons, y_moons = make_moons(n_samples=200, noise=0.2, random_state=42)
y_moons_cat = to_categorical(y_moons)
X_train, X_test, y_train, y_test = train_test_split(X_moons, y_moons_cat, test_size=0.3, random_state=42)
model_moons = Sequential([Dense(16,input_dim=2,activation='relu'), Dense(8,activation='relu'), Dense(2,activation='softmax')])
model_moons.compile(Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
history_moons = model_moons.fit(X_train, y_train, epochs=200, verbose=0)
plot_history(history_moons, "Classificazione 2D NN")

# Dataset Iris NN
scaler = StandardScaler()
X_iris_scaled = scaler.fit_transform(X_iris)
X_train, X_test, y_train, y_test = train_test_split(X_iris_scaled, y_cat, test_size=0.3, random_state=42)
model_iris_nn = Sequential([Dense(16,input_dim=4,activation='relu'), Dense(12,activation='relu'), Dense(3,activation='softmax')])
model_iris_nn.compile(Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])
history_iris_nn = model_iris_nn.fit(X_train, y_train, epochs=200, verbose=0)
plot_history(history_iris_nn, "Iris NN")


