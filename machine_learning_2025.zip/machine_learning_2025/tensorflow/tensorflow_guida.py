# ============================================================
# 📘 GUIDA PRATICA TENSORFLOW + KERAS
# Autore: SalvoNet
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ============================================================
# 1️⃣ REGRESSIONE CON RETE NEURALE
# ============================================================

print("\n================ REGRESSIONE (NN) ================\n")

# Dataset fittizio vendite vs pubblicità
X = np.array([[1],[2],[3],[4],[5]], dtype=float)
y = np.array([5,7,9,11,13], dtype=float)

# Modello feedforward semplice
model_reg = Sequential([
    Dense(8, input_dim=1, activation='relu'),
    Dense(4, activation='relu'),
    Dense(1)  # output per regressione
])

model_reg.compile(optimizer=Adam(learning_rate=0.01), loss='mse')
model_reg.fit(X, y, epochs=200, verbose=0)

# Predizione
y_pred = model_reg.predict(X)
print("Predizioni rete neurale (regression):", y_pred.flatten())

# Grafico
plt.figure(figsize=(6,4))
plt.scatter(X, y, color='blue', label='Dati reali')
plt.plot(X, y_pred, color='red', label='Predizione NN')
plt.title("Regressione con Rete Neurale")
plt.xlabel("Pubblicità (k€)")
plt.ylabel("Vendite (k unità)")
plt.legend()
plt.show()

# ============================================================
# 2️⃣ CLASSIFICAZIONE CON RETE NEURALE
# ============================================================

print("\n================ CLASSIFICAZIONE (NN) ================\n")

# Dataset fittizio (3 classi)
X_class = np.array([[0,0],[0,1],[1,0],[1,1],[0.5,0.5],[0.2,0.8],[0.8,0.2]])
y_class = np.array([0,1,1,2,1,1,1])

# One-hot encoding delle classi
y_class_cat = to_categorical(y_class, num_classes=3)

# Suddivisione train/test
X_train, X_test, y_train, y_test = train_test_split(X_class, y_class_cat, test_size=0.3, random_state=42)

# Modello classificazione
model_clf = Sequential([
    Dense(8, input_dim=2, activation='relu'),
    Dense(6, activation='relu'),
    Dense(3, activation='softmax')  # output per classificazione
])

model_clf.compile(optimizer=Adam(learning_rate=0.01), loss='categorical_crossentropy', metrics=['accuracy'])
model_clf.fit(X_train, y_train, epochs=200, verbose=0)

# Valutazione
loss, accuracy = model_clf.evaluate(X_test, y_test, verbose=0)
print("Accuracy classificazione NN:", accuracy)

# Predizioni
y_pred_class = model_clf.predict(X_test)
y_pred_class_labels = np.argmax(y_pred_class, axis=1)
print("Predizioni classi test:", y_pred_class_labels)

# ============================================================
# 3️⃣ RETE NEURALE CON DATASET IRIS
# ============================================================

print("\n================ RETE NEURALE IRIS ================\n")

from sklearn.datasets import load_iris

iris = load_iris()
X_iris = iris.data
y_iris = to_categorical(iris.target)

# Standardizzazione
scaler = StandardScaler()
X_iris_scaled = scaler.fit_transform(X_iris)

# Suddivisione train/test
X_train, X_test, y_train, y_test = train_test_split(X_iris_scaled, y_iris, test_size=0.3, random_state=42)

# Modello
model_iris = Sequential([
    Dense(16, input_dim=4, activation='relu'),
    Dense(12, activation='relu'),
    Dense(3, activation='softmax')
])

model_iris.compile(optimizer=Adam(learning_rate=0.01), loss='categorical_crossentropy', metrics=['accuracy'])
model_iris.fit(X_train, y_train, epochs=200, verbose=0)

# Valutazione
loss, accuracy = model_iris.evaluate(X_test, y_test, verbose=0)
print("Accuracy rete neurale Iris:", accuracy)

# ============================================================
# 4️⃣ VISUALIZZAZIONE PESI NEURONALI
# ============================================================

weights = model_iris.get_weights()
print("\nPesi primo layer:\n", weights[0])
print("Bias primo layer:\n", weights[1])

# ============================================================
# ✅ FINE GUIDA TENSORFLOW + KERAS
# ============================================================

print("\n🔹 Demo TensorFlow + Keras completata! Regressione, classificazione e Deep Learning pronti.")
