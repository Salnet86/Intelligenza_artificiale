# ============================================================
# 📘 GUIDA PRATICA A PANDAS + MATPLOTLIB
# Autore: SalvoNet
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# 1️⃣ CREAZIONE DI UN DATAFRAME
# ============================================================

# Dati fittizi: mesi e vendite di 3 prodotti
dati = {
    "Mese": ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu"],
    "Prodotto_A": [100, 120, 90, 150, 200, 180],
    "Prodotto_B": [80, 110, 130, 160, 170, 190],
    "Prodotto_C": [60, 70, 100, 120, 140, 160]
}

df = pd.DataFrame(dati)
print("📊 DataFrame iniziale:\n", df, "\n")

# ============================================================
# 2️⃣ OPERAZIONI BASE SU DATAFRAME
# ============================================================

# Visualizza le prime righe
print("Prime righe del DataFrame:\n", df.head(), "\n")

# Descrizione statistica (media, max, min, ecc.)
print("Statistiche descrittive:\n", df.describe(), "\n")

# Media vendite per prodotto
print("Media vendite per prodotto:\n", df[["Prodotto_A", "Prodotto_B", "Prodotto_C"]].mean(), "\n")

# Colonna nuova: totale vendite per mese
df["Totale"] = df["Prodotto_A"] + df["Prodotto_B"] + df["Prodotto_C"]
print("DataFrame con totale vendite:\n", df, "\n")

# ============================================================
# 3️⃣ GRAFICO A LINEA
# ============================================================

plt.figure(figsize=(8, 5))
plt.plot(df["Mese"], df["Prodotto_A"], marker="o", label="Prodotto A")
plt.plot(df["Mese"], df["Prodotto_B"], marker="o", label="Prodotto B")
plt.plot(df["Mese"], df["Prodotto_C"], marker="o", label="Prodotto C")
plt.title("📈 Andamento vendite prodotti")
plt.xlabel("Mese")
plt.ylabel("Vendite")
plt.legend()
plt.grid(True)
plt.show()

# ============================================================
# 4️⃣ GRAFICO A BARRE
# ============================================================

plt.figure(figsize=(8, 5))
plt.bar(df["Mese"], df["Totale"], color="skyblue")
plt.title("📊 Vendite totali per mese")
plt.xlabel("Mese")
plt.ylabel("Totale vendite")
plt.show()

# ============================================================
# 5️⃣ GRAFICO A TORTA
# ============================================================

# Vendite totali per prodotto
totali_prodotti = [
    df["Prodotto_A"].sum(),
    df["Prodotto_B"].sum(),
    df["Prodotto_C"].sum()
]

etichette = ["Prodotto A", "Prodotto B", "Prodotto C"]

plt.figure(figsize=(6, 6))
plt.pie(totali_prodotti, labels=etichette, autopct="%1.1f%%", startangle=90)
plt.title("🥧 Percentuale vendite totali per prodotto")
plt.show()

# ============================================================
# 6️⃣ GRAFICO LINEA + BARRE INSIEME (COMBINATO)
# ============================================================

fig, ax1 = plt.subplots(figsize=(8, 5))

# Barre per vendite totali
ax1.bar(df["Mese"], df["Totale"], color="lightgray", label="Totale vendite")
ax1.set_xlabel("Mese")
ax1.set_ylabel("Totale vendite", color="gray")

# Secondo asse Y per Prodotto A
ax2 = ax1.twinx()
ax2.plot(df["Mese"], df["Prodotto_A"], color="red", marker="o", label="Prodotto A")
ax2.set_ylabel("Vendite Prodotto A", color="red")

plt.title("📊 Grafico combinato: barre + linea")
plt.show()

# ============================================================
# ✅ FINE GUIDA PANDAS + MATPLOTLIB
# ============================================================
