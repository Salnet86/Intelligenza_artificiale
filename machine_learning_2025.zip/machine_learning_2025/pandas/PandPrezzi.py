# ============================================================
# 📘 ANALISI VENDITE AUTOMOBILI
# Autore: SalvoNet
# ============================================================

import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# 1️⃣ CREAZIONE DEL DATAFRAME
# ============================================================

# Dati di esempio: modelli, prezzo unitario e vendite mensili
dati_auto = {
    "Modello": ["CityCar", "SUV", "Berlina", "Sportiva", "Elettrica"],
    "Prezzo_unitario": [12000, 35000, 28000, 60000, 45000],  # in Euro
    "Vendite_Gennaio": [50, 30, 40, 10, 20],
    "Vendite_Febbraio": [60, 25, 35, 12, 25],
    "Vendite_Marzo": [55, 35, 45, 15, 30]
}

df_auto = pd.DataFrame(dati_auto)
print("📊 DataFrame vendite auto:\n", df_auto, "\n")

# ============================================================
# 2️⃣ CALCOLI BASE
# ============================================================

# Totale vendite per modello
df_auto["Vendite_totali"] = df_auto["Vendite_Gennaio"] + df_auto["Vendite_Febbraio"] + df_auto["Vendite_Marzo"]
print("Vendite totali per modello:\n", df_auto[["Modello", "Vendite_totali"]], "\n")

# Fatturato totale per modello = Prezzo_unitario * Vendite_totali
df_auto["Fatturato"] = df_auto["Prezzo_unitario"] * df_auto["Vendite_totali"]
print("Fatturato totale per modello:\n", df_auto[["Modello", "Fatturato"]], "\n")

# ============================================================
# 3️⃣ GRAFICO A BARRE: Vendite totali per modello
# ============================================================

plt.figure(figsize=(8,5))
plt.bar(df_auto["Modello"], df_auto["Vendite_totali"], color="skyblue")
plt.title("📊 Vendite totali per modello")
plt.xlabel("Modello auto")
plt.ylabel("Unità vendute")
plt.show()

# ============================================================
# 4️⃣ GRAFICO A TORTA: Percentuale del fatturato
# ============================================================

plt.figure(figsize=(6,6))
plt.pie(df_auto["Fatturato"], labels=df_auto["Modello"], autopct="%1.1f%%", startangle=90)
plt.title("🥧 Percentuale fatturato per modello")
plt.show()

# ============================================================
# 5️⃣ GRAFICO A LINEA: Vendite mese per mese
# ============================================================

plt.figure(figsize=(8,5))
mesi = ["Gennaio", "Febbraio", "Marzo"]

for i, row in df_auto.iterrows():
    vendite = [row["Vendite_Gennaio"], row["Vendite_Febbraio"], row["Vendite_Marzo"]]
    plt.plot(mesi, vendite, marker="o", label=row["Modello"])

plt.title("📈 Andamento vendite per modello")
plt.xlabel("Mese")
plt.ylabel("Unità vendute")
plt.legend()
plt.grid(True)
plt.show()

# ============================================================
# 6️⃣ GRAFICO COMBINATO: Barre totali + linea fatturato
# ============================================================

fig, ax1 = plt.subplots(figsize=(8,5))

# Barre: vendite totali
ax1.bar(df_auto["Modello"], df_auto["Vendite_totali"], color="lightgray", label="Vendite totali")
ax1.set_xlabel("Modello")
ax1.set_ylabel("Unità vendute", color="gray")

# Linea: fatturato
ax2 = ax1.twinx()
ax2.plot(df_auto["Modello"], df_auto["Fatturato"], color="red", marker="o", label="Fatturato")
ax2.set_ylabel("Fatturato (€)", color="red")

plt.title("📊 Vendite totali e fatturato per modello")
plt.show()

# ============================================================
# ✅ FINE ANALISI VENDITE AUTOMOBILI
# ============================================================
