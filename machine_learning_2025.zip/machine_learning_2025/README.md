# Docenti: Mara e Gianluca - Statistica e Intelligenza Artificiale

![AI Banner](https://cdn-icons-png.flaticon.com/512/4712/4712156.png)

## 📚 Descrizione
Questo repository raccoglie esercizi, tutorial e progetti relativi a **tecniche e tecnologie di Intelligenza Artificiale** svolti nei corsi di formazione dell'anno **2025**. Include esempi pratici di **Python, TensorFlow, Keras, Brain.js, Pandas, Matplotlib, SciPy, Flask** e molto altro.

---

## ⚙️ Installazione librerie Python

Prima di eseguire gli esempi, assicurati di avere Python 3 installato.

```bash
# Aggiorna pip
pip install --upgrade pip

# Librerie principali Python per AI e Machine Learning
pip install numpy pandas matplotlib scipy scikit-learn tensorflow keras flask


🌐 Librerie  per AI


Anno di formazione: 2025

Corsi tenuti dai docenti Mara e Gianluca

Approccio pratico: esempi, esercizi, progetti reali

Tecnologie moderne e aggiornate per il mondo dell’Intelligenza Artificiale

