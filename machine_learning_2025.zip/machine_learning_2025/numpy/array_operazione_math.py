x = np.array([1, 2, 3])
y = np.array([10, 20, 30])

# Somma e sottrazione
print(x + y)
print(y - x)

# Moltiplicazione e divisione elemento per elemento
print(x * y)
print(y / x)

# Potenza
print(x ** 2)

# Somma di tutti gli elementi
print(np.sum(x))

# Media e deviazione standard
print(np.mean(y))
print(np.std(y))
