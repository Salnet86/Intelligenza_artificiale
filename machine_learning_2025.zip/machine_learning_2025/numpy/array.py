import numpy as np

# Vettore 1D
v = np.array([1, 2, 3, 4])
print(v)

# Matrice 2D
m = np.array([[1, 2], [3, 4]])
print(m)

# Array di zeri
z = np.zeros((2, 3))
print(z)

# Array di uni
u = np.ones((3, 3))
print(u)

# Array casuale
r = np.random.rand(2, 3)
print(r)

# Range numerico (simile a range())
a = np.arange(0, 10, 2)
print(a)

# Linspace: 5 numeri tra 0 e 1
b = np.linspace(0, 1, 5)
print(b)
