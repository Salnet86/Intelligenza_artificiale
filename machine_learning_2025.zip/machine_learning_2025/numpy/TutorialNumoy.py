# ============================================================
# 📘 GUIDA PRATICA A NUMPY PER IL MACHINE LEARNING
# Autore: SalvoNet
# ============================================================

import numpy as np

# ============================================================
# 1️⃣ CREAZIONE DI ARRAY
# ============================================================

# Vettore monodimensionale (1D)
v = np.array([1, 2, 3, 4])
print("Vettore 1D:\n", v, "\n")

# Matrice bidimensionale (2D)
m = np.array([[1, 2], [3, 4]])
print("Matrice 2D:\n", m, "\n")

# Array di soli zeri (2 righe, 3 colonne)
z = np.zeros((2, 3))
print("Array di zeri:\n", z, "\n")

# Array di soli uno (3x3)
u = np.ones((3, 3))
print("Array di uno:\n", u, "\n")

# Array di numeri casuali tra 0 e 1
r = np.random.rand(2, 3)
print("Array casuale:\n", r, "\n")

# Array con numeri da 0 a 9, passo 2
a = np.arange(0, 10, 2)
print("Array con np.arange:\n", a, "\n")

# Array con 5 numeri equidistanti tra 0 e 1
b = np.linspace(0, 1, 5)
print("Array con np.linspace:\n", b, "\n")


# ============================================================
# 2️⃣ OPERAZIONI MATEMATICHE SU ARRAY
# ============================================================

x = np.array([1, 2, 3])
y = np.array([10, 20, 30])

print("Somma:", x + y)
print("Sottrazione:", y - x)
print("Moltiplicazione elemento per elemento:", x * y)
print("Divisione elemento per elemento:", y / x)
print("Potenza:", x ** 2)
print("Somma di tutti gli elementi di x:", np.sum(x))
print("Media di y:", np.mean(y))
print("Deviazione standard di y:", np.std(y), "\n")


# ============================================================
# 3️⃣ ALGEBRA LINEARE CON MATRICI
# ============================================================

A = np.array([[1, 2],
              [3, 4]])

B = np.array([[5, 6],
              [7, 8]])

print("Somma di matrici:\n", A + B)
print("Differenza:\n", A - B)
print("Moltiplicazione elemento per elemento:\n", A * B)
print("Prodotto matriciale (dot):\n", np.dot(A, B))
print("Trasposta di A:\n", A.T)
print("Inversa di A:\n", np.linalg.inv(A))
print("Determinante di A:", np.linalg.det(A), "\n")


# ============================================================
# 4️⃣ INDICIZZAZIONE E SLICING
# ============================================================

arr = np.array([[10, 20, 30],
                [40, 50, 60],
                [70, 80, 90]])

print("Elemento riga 0, colonna 1:", arr[0, 1])
print("Riga intera (1):", arr[1])
print("Colonna intera (2):", arr[:, 2])
print("Sottomatrice (righe 0-1, colonne 1-2):\n", arr[0:2, 1:3])

# Modifica di un elemento
arr[2, 2] = 999
print("Array dopo modifica:\n", arr, "\n")


# ============================================================
# 5️⃣ BROADCASTING (operazioni automatiche)
# ============================================================

A = np.array([[1, 2, 3],
              [4, 5, 6]])

b = np.array([10, 20, 30])

print("Somma di A e b (broadcasting):\n", A + b)
print("Moltiplicazione di A per 2:\n", A * 2, "\n")


# ============================================================
# 6️⃣ USO TIPO NEL MACHINE LEARNING
# ============================================================

# Input (2 campioni, 3 feature)
X = np.array([[0.1, 0.2, 0.3],
              [0.4, 0.5, 0.6]])

# Pesi (3 feature -> 1 neurone)
W = np.array([[0.2],
              [0.4],
              [0.6]])

# Bias
b = 0.1

# Calcolo uscita del neurone: y = X·W + b
y = np.dot(X, W) + b
print("Uscita del neurone (y = X·W + b):\n", y, "\n")

# ============================================================
# ✅ FINE GUIDA NUMPY
# ============================================================
