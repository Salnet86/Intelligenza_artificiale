# ============================================================
# 📘 GUIDA PRATICA A SCIKIT-LEARN
# Autore: SalvoNet
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.datasets import load_iris, make_blobs

# ============================================================
# 1️⃣ REGRESSIONE LINEARE
# ============================================================

print("\n================ REGRESSIONE LINEARE ================\n")

# Dataset fittizio vendite vs pubblicità
X = np.array([[1], [2], [3], [4], [5]])  # pubblicità in migliaia €
y = np.array([5, 7, 9, 11, 13])          # vendite in migliaia unità

# Modello
reg = LinearRegression()
reg.fit(X, y)

# Predizioni
y_pred = reg.predict(X)
print("Coefficiente:", reg.coef_)
print("Intercetta:", reg.intercept_)
print("Predizioni:", y_pred)
print("MSE:", mean_squared_error(y, y_pred))

# Grafico
plt.figure(figsize=(6,4))
plt.scatter(X, y, color="blue", label="Dati reali")
plt.plot(X, y_pred, color="red", label="Predizione")
plt.title("Regressione Lineare")
plt.xlabel("Pubblicità (k€)")
plt.ylabel("Vendite (k unità)")
plt.legend()
plt.show()

# ============================================================
# 2️⃣ CLASSIFICAZIONE - Logistic Regression
# ============================================================

print("\n================ CLASSIFICAZIONE ================\n")

# Dataset Iris (fiori)
iris = load_iris()
X_iris = iris.data
y_iris = iris.target

# Suddivisione train/test
X_train, X_test, y_train, y_test = train_test_split(X_iris, y_iris, test_size=0.3, random_state=42)

# Modello
clf = LogisticRegression(max_iter=200)
clf.fit(X_train, y_train)
y_pred_clf = clf.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred_clf))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred_clf))

# ============================================================
# 3️⃣ CLUSTERING - KMeans
# ============================================================

print("\n================ CLUSTERING (KMeans) ================\n")

# Dataset artificiale
X_cluster, y_true = make_blobs(n_samples=100, centers=3, cluster_std=1.0, random_state=42)

# Modello KMeans
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X_cluster)
y_kmeans = kmeans.predict(X_cluster)

# Grafico
plt.figure(figsize=(6,4))
plt.scatter(X_cluster[:,0], X_cluster[:,1], c=y_kmeans, cmap='viridis')
plt.scatter(kmeans.cluster_centers_[:,0], kmeans.cluster_centers_[:,1], s=100, color='red', label="Centri")
plt.title("KMeans Clustering")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.legend()
plt.show()

# ============================================================
# 4️⃣ PCA - Riduzione dimensionale
# ============================================================

print("\n================ PCA (Riduzione dimensionale) ================\n")

# Standardizzazione dati
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_iris)

# PCA riduce da 4 a 2 componenti
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
print("Varianza spiegata dalle componenti:", pca.explained_variance_ratio_)

# Grafico
plt.figure(figsize=(6,4))
for i, target_name in enumerate(iris.target_names):
    plt.scatter(X_pca[y_iris==i,0], X_pca[y_iris==i,1], label=target_name)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA su dataset Iris")
plt.legend()
plt.show()

# ============================================================
# ✅ FINE GUIDA SCIKIT-LEARN
# ============================================================

print("\n🔹 Demo scikit-learn completata! Regressione, classificazione, clustering e PCA pronti.")
