# ============================================================
# 📘 PORTFOLIO COMPLETO PYTHON: NUMPY + PANDAS + MATPLOTLIB + SCIPY + SCIKIT-LEARN
# Autore: SalvoNet
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats, optimize, integrate, interpolate, linalg
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.datasets import load_iris, make_blobs

# ============================================================
# 1️⃣ NUMPY - Array, operazioni e algebra lineare
# ============================================================

print("\n================ NUMPY ================\n")

v = np.array([1, 2, 3, 4])
m = np.array([[1, 2], [3, 4]])
print("Vettore 1D:", v)
print("Matrice 2D:\n", m)

x = np.array([1, 2, 3])
y = np.array([10, 20, 30])
print("Somma:", x + y)
print("Prodotto matriciale A·B:\n", np.dot(m, m))

A = np.array([[1, 2], [3, 4]])
print("Inversa di A:\n", np.linalg.inv(A))
print("Determinante di A:", np.linalg.det(A))

B = np.array([[1,2,3],[4,5,6]])
b = np.array([10,20,30])
print("Broadcasting A+b:\n", B+b)

X = np.array([[0.1,0.2,0.3],[0.4,0.5,0.6]])
W = np.array([[0.2],[0.4],[0.6]])
b_neurone = 0.1
y_neurone = np.dot(X,W)+b_neurone
print("Uscita neurone y = X·W + b:\n", y_neurone)

# ============================================================
# 2️⃣ PANDAS + MATPLOTLIB - Analisi vendite prodotti
# ============================================================

print("\n================ PANDAS + MATPLOTLIB ================\n")

dati = {
    "Mese": ["Gen","Feb","Mar","Apr","Mag","Giu"],
    "Prodotto_A": [100,120,90,150,200,180],
    "Prodotto_B": [80,110,130,160,170,190],
    "Prodotto_C": [60,70,100,120,140,160]
}
df = pd.DataFrame(dati)
df["Totale"] = df["Prodotto_A"] + df["Prodotto_B"] + df["Prodotto_C"]
print("DataFrame con totale vendite:\n", df)

plt.figure(figsize=(8,5))
plt.plot(df["Mese"], df["Prodotto_A"], marker="o", label="Prodotto A")
plt.plot(df["Mese"], df["Prodotto_B"], marker="o", label="Prodotto B")
plt.plot(df["Mese"], df["Prodotto_C"], marker="o", label="Prodotto C")
plt.title("Andamento vendite prodotti")
plt.xlabel("Mese")
plt.ylabel("Vendite")
plt.legend()
plt.grid(True)
plt.show()

plt.figure(figsize=(8,5))
plt.bar(df["Mese"], df["Totale"], color="skyblue")
plt.title("Vendite totali per mese")
plt.xlabel("Mese")
plt.ylabel("Totale vendite")
plt.show()

totali_prodotti = [df["Prodotto_A"].sum(), df["Prodotto_B"].sum(), df["Prodotto_C"].sum()]
plt.figure(figsize=(6,6))
plt.pie(totali_prodotti, labels=["Prodotto A","Prodotto B","Prodotto C"], autopct="%1.1f%%", startangle=90)
plt.title("Percentuale vendite totali per prodotto")
plt.show()

# ============================================================
# 3️⃣ SCIPY - Statistica, ottimizzazione, integrazione, interpolazione, algebra lineare
# ============================================================

print("\n================ SCIPY ================\n")

vendite_scipy = np.array([50,60,55,30,40,45,70,65])
print("Media:", np.mean(vendite_scipy))
print("Skewness:", stats.skew(vendite_scipy))
t_stat, p_value = stats.ttest_1samp(vendite_scipy, 50)
print("T-test vs 50:", t_stat, p_value)

def costo(x):
    return (x-5)**2 + 10
res = optimize.minimize(costo, x0=0)
print("Minimo funzione costo:", res.x, "Costo minimo:", res.fun)

def vendite_mese(x):
    return 50 + 10*np.sin(x)
area, errore = integrate.quad(vendite_mese, 0, np.pi)
print("Vendite totali integrate:", area)

mesi = np.array([1,2,3,4,5])
vendite_mensili = np.array([50,60,55,70,65])
f_lineare = interpolate.interp1d(mesi, vendite_mensili, kind="linear")
mesi_fini = np.linspace(1,5,50)
plt.figure(figsize=(8,5))
plt.plot(mesi, vendite_mensili,"o", label="Dati originali")
plt.plot(mesi_fini,f_lineare(mesi_fini), "-", label="Interpolazione lineare")
plt.title("Interpolazione vendite mese per mese")
plt.xlabel("Mese")
plt.ylabel("Vendite")
plt.legend()
plt.grid(True)
plt.show()

A = np.array([[2,1,3],[1,2,1],[3,0,2]])
b = np.array([1,2,3])
x = linalg.solve(A,b)
print("Soluzione sistema lineare Ax=b:", x)
autovalori, autovettori = linalg.eig(A)
print("Autovalori:", autovalori)
print("Autovettori:\n", autovettori)

# ============================================================
# 4️⃣ SCIKIT-LEARN - Regressione, classificazione, clustering, PCA
# ============================================================

print("\n================ SCIKIT-LEARN ================\n")

# Regressione lineare
X_reg = np.array([[1],[2],[3],[4],[5]])
y_reg = np.array([5,7,9,11,13])
reg = LinearRegression()
reg.fit(X_reg, y_reg)
y_pred = reg.predict(X_reg)
print("Regressione lineare - Coeff:", reg.coef_, "Intercetta:", reg.intercept_)
print("Predizioni:", y_pred)

plt.figure(figsize=(6,4))
plt.scatter(X_reg, y_reg, color="blue", label="Dati reali")
plt.plot(X_reg, y_pred, color="red", label="Predizione")
plt.title("Regressione Lineare")
plt.xlabel("Pubblicità (k€)")
plt.ylabel("Vendite (k unità)")
plt.legend()
plt.show()

# Classificazione - Logistic Regression
iris = load_iris()
X_iris = iris.data
y_iris = iris.target
X_train, X_test, y_train, y_test = train_test_split(X_iris, y_iris, test_size=0.3, random_state=42)
clf = LogisticRegression(max_iter=200)
clf.fit(X_train, y_train)
y_pred_clf = clf.predict(X_test)
print("Logistic Regression Accuracy:", accuracy_score(y_test, y_pred_clf))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred_clf))

# Clustering - KMeans
X_cluster, y_true = make_blobs(n_samples=100, centers=3, cluster_std=1.0, random_state=42)
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X_cluster)
y_kmeans = kmeans.predict(X_cluster)
plt.figure(figsize=(6,4))
plt.scatter(X_cluster[:,0], X_cluster[:,1], c=y_kmeans, cmap='viridis')
plt.scatter(kmeans.cluster_centers_[:,0], kmeans.cluster_centers_[:,1], s=100, color='red', label="Centri")
plt.title("KMeans Clustering")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.legend()
plt.show()

# PCA
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_iris)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
print("PCA - Varianza spiegata:", pca.explained_variance_ratio_)
plt.figure(figsize=(6,4))
for i, target_name in enumerate(iris.target_names):
    plt.scatter(X_pca[y_iris==i,0], X_pca[y_iris==i,1], label=target_name)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA su dataset Iris")
plt.legend()
plt.show()

# ============================================================
# ✅ FINE MEGA PORTFOLIO COMPLETO
# ============================================================

print("\n🔹 Portfolio demo completo eseguito! Tutti esempi pronti per mostrare competenze Python, Data Analysis e Machine Learning.")
