# ============================================================
# 📘 DEMO CLASSIFICAZIONE CON to_categorical (Keras)
# Autore: SalvoNet
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split

# ============================================================
# 1️⃣ CREAZIONE DATASET 2D (make_moons)
# ============================================================
X, y = make_moons(n_samples=200, noise=0.2, random_state=42)
print("Etichette originali:", y[:10])

# ============================================================
# 2️⃣ CONVERSIONE ETICHETTE IN ONE-HOT
# ============================================================
y_cat = to_categorical(y)
print("\nOne-Hot Encoding (prime 10 righe):\n", y_cat[:10])

# ============================================================
# 3️⃣ SUDDIVISIONE TRAIN/TEST
# ============================================================
X_train, X_test, y_train, y_test = train_test_split(X, y_cat, test_size=0.3, random_state=42)

# ============================================================
# 4️⃣ COSTRUZIONE RETE NEURALE
# ============================================================
model = Sequential([
    Dense(16, input_dim=2, activation='relu'),
    Dense(8, activation='relu'),
    Dense(2, activation='softmax')  # output per classificazione 2 classi
])

model.compile(optimizer=Adam(0.01), loss='categorical_crossentropy', metrics=['accuracy'])

# ============================================================
# 5️⃣ ADDDESTRAMENTO
# ============================================================
history = model.fit(X_train, y_train, epochs=200, verbose=0)

# ============================================================
# 6️⃣ GRAFICO TRAINING LOSS E ACCURACY
# ============================================================
plt.figure(figsize=(8,4))
plt.plot(history.history['loss'], label='Loss')
plt.plot(history.history['accuracy'], label='Accuracy')
plt.title("Training Loss / Accuracy")
plt.xlabel("Epoca")
plt.ylabel("Valore")
plt.legend()
plt.grid(True)
plt.show()

# ============================================================
# 7️⃣ VALUTAZIONE SUL TEST SET
# ============================================================
loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
print(f"\nAccuracy sul test set: {accuracy:.2f}")

# ============================================================
# 8️⃣ PREDIZIONI E GRAFICO CLASSI
# ============================================================
y_pred = np.argmax(model.predict(X_test), axis=1)
y_true = np.argmax(y_test, axis=1)

plt.figure(figsize=(6,4))
plt.scatter(X_test[:,0], X_test[:,1], c=y_pred, cmap='coolwarm', edgecolor='k', label='Predizioni')
plt.title("Predizioni rete neurale (make_moons)")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.show()

# ============================================================
# ✅ FINE DEMO to_categorical + NN
# ============================================================
print("\n🔹 Demo completata! to_categorical + rete neurale classificazione funzionante.")
