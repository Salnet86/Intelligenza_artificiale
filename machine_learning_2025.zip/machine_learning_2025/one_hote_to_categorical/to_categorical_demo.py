# ============================================================
# 📘 ESEMPIO to_categorical (Keras) - One-Hot Encoding
# Autore: SalvoNet
# ============================================================

import numpy as np
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# 1️⃣ Dataset di classi fittizie
# ------------------------------------------------------------
y_labels = np.array([0, 1, 2, 1, 0, 2, 1, 0])
print("Etichette originali:", y_labels)

# ------------------------------------------------------------
# 2️⃣ Conversione in one-hot encoding
# ------------------------------------------------------------
y_one_hot = to_categorical(y_labels)
print("\nOne-Hot Encoding:\n", y_one_hot)

# ------------------------------------------------------------
# 3️⃣ Visualizzazione grafica delle etichette one-hot
# ------------------------------------------------------------
plt.figure(figsize=(6,4))
plt.imshow(y_one_hot, cmap='viridis', aspect='auto')
plt.colorbar(label='Valore One-Hot')
plt.title("Visualizzazione One-Hot Encoding")
plt.xlabel("Classe")
plt.ylabel("Campione")
plt.yticks(range(len(y_labels)), [f"Campione {i}" for i in range(len(y_labels))])
plt.show()

# ------------------------------------------------------------
# 4️⃣ Come usare in rete neurale
# ------------------------------------------------------------
# Esempio breve: input X e output y_one_hot per classificazione
X_dummy = np.random.rand(len(y_labels), 4)  # 4 feature casuali
print("\nInput dummy X:\n", X_dummy)
print("\nOutput one-hot y:\n", y_one_hot)

print("\n🔹 Demo to_categorical completata!")
