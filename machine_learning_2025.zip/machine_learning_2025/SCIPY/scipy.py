# ============================================================
# 📘 PORTFOLIO DEMO PYTHON: NUMPY + PANDAS + MATPLOTLIB + SCIPY
# Autore: SalvoNet
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats, optimize, integrate, interpolate, linalg

# ============================================================
# 1️⃣ NUMPY - Array, operazioni e algebra lineare
# ============================================================

print("\n================ NUMPY ================\n")

# Creazione array
v = np.array([1, 2, 3, 4])
m = np.array([[1, 2], [3, 4]])
print("Vettore 1D:", v)
print("Matrice 2D:\n", m)

# Operazioni
x = np.array([1, 2, 3])
y = np.array([10, 20, 30])
print("Somma:", x + y)
print("Prodotto matriciale A·B:\n", np.dot(m, m))

# Algebra lineare
A = np.array([[1, 2], [3, 4]])
print("Inversa di A:\n", np.linalg.inv(A))
print("Determinante di A:", np.linalg.det(A))

# Broadcasting
B = np.array([[1,2,3],[4,5,6]])
b = np.array([10,20,30])
print("Broadcasting A+b:\n", B+b)

# Uscita neurone (ML)
X = np.array([[0.1,0.2,0.3],[0.4,0.5,0.6]])
W = np.array([[0.2],[0.4],[0.6]])
b_neurone = 0.1
y = np.dot(X,W)+b_neurone
print("Uscita neurone y = X·W + b:\n", y)

# ============================================================
# 2️⃣ PANDAS + MATPLOTLIB - Analisi vendite prodotti
# ============================================================

print("\n================ PANDAS + MATPLOTLIB ================\n")

dati = {
    "Mese": ["Gen","Feb","Mar","Apr","Mag","Giu"],
    "Prodotto_A": [100,120,90,150,200,180],
    "Prodotto_B": [80,110,130,160,170,190],
    "Prodotto_C": [60,70,100,120,140,160]
}
df = pd.DataFrame(dati)
df["Totale"] = df["Prodotto_A"] + df["Prodotto_B"] + df["Prodotto_C"]
print("DataFrame con totale vendite:\n", df)

# Grafico a linee
plt.figure(figsize=(8,5))
plt.plot(df["Mese"], df["Prodotto_A"], marker="o", label="Prodotto A")
plt.plot(df["Mese"], df["Prodotto_B"], marker="o", label="Prodotto B")
plt.plot(df["Mese"], df["Prodotto_C"], marker="o", label="Prodotto C")
plt.title("Andamento vendite prodotti")
plt.xlabel("Mese")
plt.ylabel("Vendite")
plt.legend()
plt.grid(True)
plt.show()

# Grafico a barre
plt.figure(figsize=(8,5))
plt.bar(df["Mese"], df["Totale"], color="skyblue")
plt.title("Vendite totali per mese")
plt.xlabel("Mese")
plt.ylabel("Totale vendite")
plt.show()

# Grafico a torta
totali_prodotti = [df["Prodotto_A"].sum(), df["Prodotto_B"].sum(), df["Prodotto_C"].sum()]
plt.figure(figsize=(6,6))
plt.pie(totali_prodotti, labels=["Prodotto A","Prodotto B","Prodotto C"], autopct="%1.1f%%", startangle=90)
plt.title("Percentuale vendite totali per prodotto")
plt.show()

# ============================================================
# 3️⃣ SCIPY - Statistica, ottimizzazione, integrazione, interpolazione, algebra lineare
# ============================================================

print("\n================ SCIPY ================\n")

# STATISTICA
vendite_scipy = np.array([50,60,55,30,40,45,70,65])
print("Media:", np.mean(vendite_scipy))
print("Skewness:", stats.skew(vendite_scipy))
t_stat, p_value = stats.ttest_1samp(vendite_scipy, 50)
print("T-test vs 50:", t_stat, p_value)

# OTTIMIZZAZIONE
def costo(x):
    return (x-5)**2 + 10
res = optimize.minimize(costo, x0=0)
print("Minimo funzione costo:", res.x, "Costo minimo:", res.fun)

# INTEGRAZIONE
def vendite_mese(x):
    return 50 + 10*np.sin(x)
area, errore = integrate.quad(vendite_mese, 0, np.pi)
print("Vendite totali integrate:", area)

# INTERPOLAZIONE
mesi = np.array([1,2,3,4,5])
vendite_mensili = np.array([50,60,55,70,65])
f_lineare = interpolate.interp1d(mesi, vendite_mensili, kind="linear")
mesi_fini = np.linspace(1,5,50)
plt.figure(figsize=(8,5))
plt.plot(mesi, vendite_mensili,"o", label="Dati originali")
plt.plot(mesi_fini,f_lineare(mesi_fini), "-", label="Interpolazione lineare")
plt.title("Interpolazione vendite mese per mese")
plt.xlabel("Mese")
plt.ylabel("Vendite")
plt.legend()
plt.grid(True)
plt.show()

# ALGEBRA LINEARE
A = np.array([[2,1,3],[1,2,1],[3,0,2]])
b = np.array([1,2,3])
x = linalg.solve(A,b)
print("Soluzione sistema lineare Ax=b:", x)
autovalori, autovettori = linalg.eig(A)
print("Autovalori:", autovalori)
print("Autovettori:\n", autovettori)

# ============================================================
# ✅ FINE MEGA PORTFOLIO DEMO
# ============================================================

print("\n🔹 Demo completata! Tutti esempi pronti per mostrare competenze Python, Data Analysis e SciPy.")
