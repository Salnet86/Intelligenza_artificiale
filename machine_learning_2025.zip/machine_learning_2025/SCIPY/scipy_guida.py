# ============================================================
# 📘 GUIDA PRATICA A SCIPY
# Autore: SalvoNet
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats, optimize, integrate, interpolate, linalg

# ============================================================
# 1️⃣ STATISTICA
# ============================================================

# Dataset vendite auto (fittizio)
vendite = np.array([50, 60, 55, 30, 40, 45, 70, 65])

print("📊 Statistiche del dataset vendite:")
print("Media:", np.mean(vendite))
print("Mediana:", np.median(vendite))
print("Varianza:", np.var(vendite))
print("Deviazione standard:", np.std(vendite))
print("Skewness (asimmetria):", stats.skew(vendite))
print("Kurtosis (appiattimento):", stats.kurtosis(vendite), "\n")

# Test statistico: t-test per media vs valore 50
t_stat, p_value = stats.ttest_1samp(vendite, 50)
print("T-test vs 50:", "t =", t_stat, ", p =", p_value, "\n")


# ============================================================
# 2️⃣ OTTIMIZZAZIONE
# ============================================================

# Funzione da minimizzare (es. costo in funzione della quantità)
def costo(x):
    return (x - 5)**2 + 10

# Trova minimo
res = optimize.minimize(costo, x0=0)  # punto di partenza x0=0
print("📈 Ottimizzazione funzione costo:")
print("Valore minimo di x:", res.x)
print("Costo minimo:", res.fun, "\n")


# ============================================================
# 3️⃣ INTEGRAZIONE NUMERICA
# ============================================================

# Integrale di una funzione (es. vendite nel tempo)
def vendite_mese(x):
    return 50 + 10 * np.sin(x)  # funzione fittizia

area, errore = integrate.quad(vendite_mese, 0, np.pi)  # integrale tra 0 e pi
print("📐 Integrazione vendite:")
print("Vendite totali previste (integrale):", area)
print("Errore stimato:", errore, "\n")


# ============================================================
# 4️⃣ INTERPOLAZIONE
# ============================================================

# Dati vendite mese per mese
mesi = np.array([1, 2, 3, 4, 5])
vendite_mensili = np.array([50, 60, 55, 70, 65])

# Interpolazione lineare
f_lineare = interpolate.interp1d(mesi, vendite_mensili, kind="linear")

# Interpolazione spline cubica
f_spline = interpolate.interp1d(mesi, vendite_mensili, kind="cubic")

# Nuovi punti mese per curva più liscia
mesi_fini = np.linspace(1, 5, 50)

plt.figure(figsize=(8,5))
plt.plot(mesi, vendite_mensili, "o", label="Dati originali")
plt.plot(mesi_fini, f_lineare(mesi_fini), "-", label="Interpolazione lineare")
plt.plot(mesi_fini, f_spline(mesi_fini), "--", label="Spline cubica")
plt.title("📈 Interpolazione vendite mese per mese")
plt.xlabel("Mese")
plt.ylabel("Vendite")
plt.legend()
plt.grid(True)
plt.show()


# ============================================================
# 5️⃣ ALGEBRA LINEARE AVANZATA
# ============================================================

# Matrice fittizia
A = np.array([[2, 1, 3],
              [1, 2, 1],
              [3, 0, 2]])

b = np.array([1, 2, 3])

# Risoluzione sistema lineare Ax = b
x = linalg.solve(A, b)
print("🧮 Soluzione sistema lineare Ax=b:", x)

# Calcolo autovalori e autovettori
autovalori, autovettori = linalg.eig(A)
print("Autovalori:", autovalori)
print("Autovettori:\n", autovettori)

# Decomposizione LU
P, L, U = linalg.lu(A)
print("Matrice L (triangolare inferiore):\n", L)
print("Matrice U (triangolare superiore):\n", U, "\n")

# ============================================================
# ✅ FINE GUIDA SCIPY
# ============================================================
