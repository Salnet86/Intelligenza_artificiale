link = "https://www.sito.it"
x = [ord(c)/255 for c in link]
print(x)
