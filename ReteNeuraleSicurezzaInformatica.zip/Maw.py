# Apri il file in modalità binaria
file_path = "LinkFalsi.py"  # Sostituisci con il tuo file
file = open(file_path, "rb")

# Leggi tutto il contenuto
byte_data = file.read()

# Chiudi il file
file.close()

# Normalizza i byte dividendo per 255
normalized_data = []
for byte in byte_data:
    normalized_data.append(byte / 255)

# Stampa i primi 10 valori normalizzati per controllo
print(normalized_data[:10])
