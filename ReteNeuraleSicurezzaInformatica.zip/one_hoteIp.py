# Lista di porte che vogliamo codificare
porte = [80, 22, 443]

# Troviamo tutte le porte uniche (categorie)
categorie = list(set(porte))

# Creiamo una matrice vuota per il one-hot
one_hot_matrix = []

# Cicliamo ogni porta
for p in porte:
    # Inizializziamo un vettore di zeri lungo quanto le categorie
    vettore = [0] * len(categorie)
    
    # Troviamo la posizione della porta nella lista categorie
    indice = categorie.index(p)
    
    # Mettiamo 1 nella posizione giusta
    vettore[indice] = 1
    
    # Aggiungiamo il vettore alla matrice finale
    one_hot_matrix.append(vettore)

# Stampa risultati
print("Porte originali:", porte)
print("Categorie:", categorie)
print("One-hot encoding:")
for riga in one_hot_matrix:
    print(riga)
