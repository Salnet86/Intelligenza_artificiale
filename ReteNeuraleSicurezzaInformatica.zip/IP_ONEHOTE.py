porte = [80, 22, 443, 80, 22]

categorie = []  # lista vuota dove mettiamo solo i valori unici

# Scorriamo la lista delle porte
for p in porte:
    # Se la porta non è già nella lista categorie, la aggiungiamo
    if p not in categorie:
        categorie.append(p)

print("Lista originale:", porte)
print("Categorie uniche:", categorie)


one_hot_matrix = []

for p in porte:
    vettore = [0] * len(categorie)
    indice = categorie.index(p)  # trova la posizione della porta
    vettore[indice] = 1
    one_hot_matrix.append(vettore)

print("One-hot encoding:")
for riga in one_hot_matrix:
    print(riga)
