import math

# Vettore di input
x = [0.75, 0.66, 0.003, 0.019, 1, 0, 0, 1, 0, 0]

# Pesi randomici per 2 neuroni hidden (10 input -> 2 hidden)
w_hidden = [
    [0.2, -0.1, 0.4, 0.1, 0.5, -0.3, 0.2, 0.1, 0, 0],
    [-0.3, 0.2, 0.1, 0.4, -0.2, 0.3, 0, 0.2, 0.1, 0]
]

# Bias hidden
b_hidden = [0.1, -0.1]

# Pesi output (2 hidden -> 1 output)
w_output = [0.3, -0.2]

# Bias output
b_output = 0.05

# Funzione sigmoide
def sigmoid(z):
    return 1 / (1 + math.exp(-z))

# --- Forward pass hidden layer ---
hidden = []
for i in range(2):
    z = b_hidden[i]
    for j in range(10):
        z += x[j] * w_hidden[i][j]
    a = sigmoid(z)
    hidden.append(a)

# --- Forward pass output layer ---
z_out = b_output
for i in range(2):
    z_out += hidden[i] * w_output[i]
output = sigmoid(z_out)

print("Output hidden layer:", hidden)
print("Output finale (probabilità attacco):", output)
