x = ["ciao", "ciao", "bene"]
vocabolo=[]
for i in range(len(x)):
    c=0
    for j in range(i+1):
        
        if x[i] == x[j]:
            c += 1
            #print(x[i])
    if c==1:
        vocabolo.append(x[i])
      
for v in vocabolo:
    print(v)

