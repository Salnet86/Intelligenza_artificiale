

parole=["ciao","bene","come","stai","ciao","stai"]

vocabolo=[]

for parola in parole:
    if parola not in  vocabolo:
        vocabolo.append(parola)

for x in vocabolo:
    print(x)

