x = ["ciao", "ciao", "bene"]
vocabolo = list(set(x))
print(vocabolo)
