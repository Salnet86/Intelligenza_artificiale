-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Giu 20, 2025 alle 18:35
-- Versione del server: 8.0.36
-- Versione PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_informaticadb`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `frasi_risposte`
--

CREATE TABLE `frasi_risposte` (
  `id` int NOT NULL,
  `frase` varchar(255) DEFAULT NULL,
  `risposta` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `frasi_risposte`
--

INSERT INTO `frasi_risposte` (`id`, `frase`, `risposta`) VALUES
(9, 'chi sei', 'Sono un assistente virtuale.'),
(8, 'come stai', 'Sto bene, grazie! E tu?'),
(7, 'salve', 'Ciao! Come posso aiutarti?'),
(6, 'ciao', 'Ciao! Come posso aiutarti?'),
(10, 'cosa fai', 'Ti aiuto a rispondere alle domande.'),
(11, 'dove sei', 'Sono nel tuo browser.'),
(12, 'addio', 'A presto!');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `frasi_risposte`
--
ALTER TABLE `frasi_risposte`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `frasi_risposte`
--
ALTER TABLE `frasi_risposte`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
