<?php
header("Content-Type: application/json");

$conn = new mysqli("localhost", "informaticadb", "password", "nomeutente");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connessione al DB fallita"]);
    exit;
}

$sql = "SELECT frase, risposta FROM frasi_risposte";
$result = $conn->query($sql);

$frasi = [];
$risposte = [];

while ($row = $result->fetch_assoc()) {
    $frasi[] = $row["frase"];
    $risposte[] = $row["risposta"];
}

echo json_encode(["frasi" => $frasi, "risposte" => $risposte]);
?>
