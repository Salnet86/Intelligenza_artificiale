import random

# Dati di input (temperature)
X = [10, 20, 40, 50, 100]

# Pesi casuali
weights = [random.random() for _ in range(5)]

# Bias casuale
bias = random.random()

# Calcolo dell'output (somma pesata + bias)
output = sum(x * w for x, w in zip(X, weights)) + bias

# Mostriamo i risultati
print(f"Temperature: {X}")
print(f"Pesi: {weights}")
print(f"Bias: {bias}")
print(f"Somma pesata + bias: {output}")
