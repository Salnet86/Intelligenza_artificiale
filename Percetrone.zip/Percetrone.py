# Dati di input (temperature)
X = [10, 20, 40, 50, 100]  # Temperature
y = [0, 0, 1, 1, 1]  # Etichette (0 = bassa, 1 = alta)

# Inizializzazione dei pesi e del bias
weights = [0.5]  # Pesi iniziali (un solo peso per il perceptrone)
bias = 0.5  # Bias iniziale

# Parametri dell'allenamento
epochs = 100  # Numero di epoche (cicli di allenamento)
learning_rate = 0.1  # Tasso di apprendimento

# Inizio dell'allenamento del perceptrone
for epoch in range(epochs):
    for i in range(len(X)):
        # 1. Calcoliamo la somma pesata (S = x * w + b)
        weighted_sum = X[i] * weights[0] + bias  # somma pesata

        # 2. Calcoliamo l'output usando la funzione di attivazione (soglia)
        if weighted_sum > 0:
            prediction = 1
        else:
            prediction = 0

        # 3. Calcoliamo l'errore (target - previsione)
        error = y[i] - prediction

        # 4. Aggiorniamo i pesi e il bias
        weights[0] += learning_rate * error * X[i]  # Aggiorna il peso
        bias += learning_rate * error  # Aggiorna il bias

    # Stampa il progresso ogni epoca
    print(f"Epoca {epoch + 1}/{epochs} - Pesi: {weights} Bias: {bias}")

# Risultati finali
print("\nPesi finali:", weights)
print("Bias finale:", bias)
